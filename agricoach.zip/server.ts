/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());

// Initialisation du client Google GenAI avec la clé de sécurité injectée par l'environnement
const apiKey = process.env.GEMINI_API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

interface VoiceAssistantRequestBody {
  userQuery: string;
  userName?: string;
  userLocality?: string;
  cropName?: string;
  currentStepNumber?: number;
  currentStepTitle?: string;
  completedSteps?: string[];
}

app.post('/api/voice-assistant', async (req: Request<{}, {}, VoiceAssistantRequestBody>, res: Response) => {
  try {
    const {
      userQuery,
      userName = 'Koffi',
      userLocality = 'Yamoussoukro',
      cropName = 'Maïs',
      currentStepNumber = 2,
      currentStepTitle = 'Préparation du sol',
      completedSteps = []
    } = req.body;

    if (!userQuery || userQuery.trim() === '') {
      res.status(400).json({ error: 'La requête utilisateur ne peut pas être vide.' });
      return;
    }

    const systemInstruction = `Tu es AgriCoach, l'assistant vocal agricole intelligent dédié aux agriculteurs de Côte d'Ivoire, notamment aux débutants.
Tu t'adresses directement à l'agriculteur de manière orale, bienveillante, claire et pratique.
Données de l'agriculteur en cours :
- Nom : ${userName}
- Localité en Côte d'Ivoire : ${userLocality}
- Culture suivie : ${cropName}
- Étape actuelle : Étape ${currentStepNumber} (${currentStepTitle})
- Étapes déjà validées : ${completedSteps.length > 0 ? completedSteps.join(', ') : 'Aucune étape validée pour le moment'}

Consignes impératives :
1. Réponds en français oral, accessible et direct, avec un ton encourageant et respectueux.
2. Limite ta réponse à 2 à 4 phrases maximum pour qu'elle soit facilement audible et comprise vocalement sur la parcelle.
3. Base tes réponses sur la réalité agronomique de la Côte d'Ivoire (types de sols de la région de ${userLocality}, régime des pluies, daba, compost, NPK, urée, chenille légionnaire, variétés locales).
4. Ne fais jamais de jargon scientifique abstrait ou inutile. Donne l'action précise : quoi faire, comment le faire ou quand le faire.
5. Si l'agriculteur te salue ou demande quoi faire, rappelle-lui son étape actuelle (${currentStepTitle}) et propose la prochaine tâche.`;

    if (!apiKey) {
      // Réponse de secours locale en cas d'absence temporaire de clé
      const fallbackResponse = `Bonjour ${userName} ! À ${userLocality}, pour votre culture de ${cropName}, vous êtes à l'étape : ${currentStepTitle}. Veillez à bien respecter les 20 cm de profondeur et à apporter votre compost. Avez-vous besoin d'un conseil spécifique ?`;
      res.json({ responseText: fallbackResponse });
      return;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: userQuery,
      config: {
        systemInstruction,
        temperature: 0.6,
        maxOutputTokens: 250,
      }
    });

    const reply = response.text?.trim() || `Très bien ${userName}. Pour votre parcelle de ${cropName} à ${userLocality}, suivez attentivement l'étape de ${currentStepTitle}. Que souhaitez-vous savoir d'autre ?`;
    res.json({ responseText: reply });
  } catch (error: any) {
    console.error('Erreur assistant vocal Gemini :', error);
    res.status(500).json({
      error: 'Erreur lors du traitement de la requête vocale',
      responseText: `Je vous entends bien, mais j'ai une petite difficulté de connexion. Pour votre culture de ${req.body.cropName || 'maïs'} à ${req.body.userLocality || 'Yamoussoukro'}, concentrez-vous sur l'étape de ${req.body.currentStepTitle || 'préparation'}.`
    });
  }
});

// En développement, monter le middleware Vite ; en production, servir dist
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Serveur AgriCoach démarré sur http://0.0.0.0:${PORT}`);
  });
}

startServer();
