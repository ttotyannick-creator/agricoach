/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { CROP_IMAGES, getCropByIdWithProgress } from '../data/agronomyData';
import { UserProfile } from '../types/agricoach';

interface ProgressionScreenProps {
  userProfile: UserProfile;
  onBack: () => void;
  onGoToActivities: (stepIndex?: number) => void;
  onReadAloud?: (text: string) => void;
}

export const ProgressionScreen: React.FC<ProgressionScreenProps> = ({
  userProfile,
  onBack,
  onGoToActivities,
  onReadAloud,
}) => {
  const activeCrop = getCropByIdWithProgress(userProfile.cropSelectedId, userProfile);
  const steps = activeCrop.steps;

  // Calcul du pourcentage réel de progression
  const totalSteps = steps.length || 6;
  const completedSteps = steps.filter((s) => s.completed);
  const completedCount = completedSteps.length;
  const progressPercent = Math.round((completedCount / totalSteps) * 100);

  // SVG ring calculations
  const radius = 54;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progressPercent / 100) * circumference;

  return (
    <div className="pb-32 max-w-md mx-auto">
      {/* Top App Bar */}
      <header className="bg-surface border-b border-outline-variant flex justify-between items-center px-margin-mobile h-[56px] w-full sticky top-0 z-40 bg-opacity-95 backdrop-blur-sm">
        <div className="flex items-center gap-base">
          <button
            onClick={onBack}
            className="material-symbols-outlined text-primary cursor-pointer active:scale-95 transition-transform mr-1"
            title="Retour à l'accueil"
          >
            arrow_back
          </button>
          <div className="w-8 h-8 rounded-full bg-secondary-container flex items-center justify-center overflow-hidden border border-outline-variant">
            {CROP_IMAGES.farmerSmall ? (
              <img src={CROP_IMAGES.farmerSmall} alt="Avatar" className="w-full h-full object-cover" />
            ) : (
              <span className="material-symbols-outlined text-on-secondary-container text-[20px]">
                person
              </span>
            )}
          </div>
          <h1 className="text-[22px] leading-[28px] font-bold text-primary">Progression</h1>
        </div>
        {onReadAloud && (
          <button
            onClick={() =>
              onReadAloud(
                `Cycle du ${activeCrop.name} : ${progressPercent}% terminé. ${completedCount} étapes sur ${totalSteps} validées. Votre progression est en bonne voie.`
              )
            }
            className="text-primary hover:bg-primary/10 p-2 rounded-full cursor-pointer"
            title="Écouter le bilan de progression"
          >
            <span className="material-symbols-outlined">volume_up</span>
          </button>
        )}
      </header>

      <main className="px-margin-mobile mt-stack-lg">
        {/* Hero Progress Card (Conforme à Image_4) */}
        <section className="bg-surface-container-lowest border border-outline-variant rounded-xl p-gutter shadow-sm mb-stack-lg overflow-hidden relative">
          <div className="flex flex-col items-center justify-center py-stack-md relative z-10">
            <div className="relative flex items-center justify-center mb-base">
              {/* Progress Circle SVG */}
              <svg className="w-32 h-32">
                <circle
                  className="text-surface-container stroke-current"
                  cx="64"
                  cy="64"
                  fill="transparent"
                  r={radius}
                  strokeWidth="12"
                />
                <circle
                  className="text-primary stroke-current progress-ring__circle"
                  cx="64"
                  cy="64"
                  fill="transparent"
                  r={radius}
                  strokeDasharray={circumference}
                  strokeDashoffset={strokeDashoffset}
                  strokeLinecap="round"
                  strokeWidth="12"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-[32px] leading-[40px] font-bold text-primary">
                  {progressPercent}%
                </span>
                <span className="text-[14px] leading-[20px] font-semibold text-on-surface-variant">
                  Terminé
                </span>
              </div>
            </div>
            <h2 className="text-[20px] leading-[28px] font-semibold text-on-surface text-center px-4">
              Cycle du {activeCrop.name} : En bonne voie !
            </h2>
            <p className="text-[16px] leading-[24px] text-on-surface-variant text-center mt-base">
              {totalSteps - completedCount > 0
                ? `Plus que ${totalSteps - completedCount} étape${totalSteps - completedCount > 1 ? 's' : ''} avant la récolte.`
                : 'Félicitations ! Toutes les étapes du cycle sont validées.'}
            </p>
          </div>
          {/* Decorative image background */}
          <div className="absolute top-0 right-0 opacity-10 -mr-8 -mt-8 pointer-events-none">
            <span className="material-symbols-outlined" style={{ fontSize: '160px' }}>
              eco
            </span>
          </div>
        </section>

        {/* ============================================================== */}
        {/* PARCOURS AGRICOLE COMPLET : LES 6 GRANDES ÉTAPES IDENTIFIÉES   */}
        {/* ============================================================== */}
        <section className="mb-stack-lg">
          <div className="flex items-center gap-base mb-stack-md">
            <span className="material-symbols-outlined text-primary text-[22px]">format_list_numbered</span>
            <h3 className="text-[20px] leading-[28px] font-semibold text-on-surface">
              Les 6 étapes de production
            </h3>
          </div>

          <div className="space-y-3">
            {steps.map((step, idx) => {
              const isCompleted = step.completed;
              const isCurrent = !isCompleted && (idx === 0 || steps[idx - 1].completed);
              const isLocked = !isCompleted && !isCurrent;

              return (
                <div
                  key={step.id}
                  onClick={() => {
                    if (!isLocked) {
                      onGoToActivities(idx);
                    }
                  }}
                  className={`rounded-2xl p-4 border transition-all ${
                    isCurrent
                      ? 'bg-surface border-2 border-primary-container shadow-xs cursor-pointer active:scale-[0.99]'
                      : isCompleted
                      ? 'bg-surface-container-low border-outline-variant cursor-pointer'
                      : 'bg-surface-container-lowest/60 border-outline-variant/60 opacity-75'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3">
                      <div
                        className={`w-9 h-9 rounded-full flex items-center justify-center font-bold text-sm shrink-0 mt-0.5 ${
                          isCompleted
                            ? 'bg-primary text-white'
                            : isCurrent
                            ? 'bg-primary-container text-on-primary-container'
                            : 'bg-surface-container text-outline'
                        }`}
                      >
                        {isCompleted ? (
                          <span className="material-symbols-outlined text-[18px]">check</span>
                        ) : (
                          step.stepNumber
                        )}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold uppercase tracking-wider text-on-surface-variant">
                            Étape {step.stepNumber}
                          </span>
                          {isCurrent && (
                            <span className="bg-primary text-on-primary px-2 py-0.5 rounded-full text-[11px] font-bold uppercase">
                              En cours
                            </span>
                          )}
                          {isCompleted && (
                            <span className="text-primary font-semibold text-xs flex items-center gap-0.5">
                              Validé ✓
                            </span>
                          )}
                        </div>
                        <h4 className="font-bold text-[16px] text-on-surface leading-tight mt-0.5">
                          {step.title}
                        </h4>
                        <p className="text-[13px] text-on-surface-variant mt-1 line-clamp-2">
                          {step.shortDescription}
                        </p>
                      </div>
                    </div>

                    <div className="shrink-0 pt-1">
                      {isCompleted ? (
                        <span className="material-symbols-outlined text-primary text-[20px]">
                          task_alt
                        </span>
                      ) : isCurrent ? (
                        <span className="material-symbols-outlined text-primary text-[20px]">
                          chevron_right
                        </span>
                      ) : (
                        <span className="material-symbols-outlined text-outline text-[20px]">
                          lock
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Bouton d'action direct vers l'étape en cours */}
        <button
          onClick={() => onGoToActivities()}
          className="w-full h-[56px] bg-primary text-on-primary rounded-xl font-bold text-[18px] flex items-center justify-center gap-base active:scale-95 transition-transform shadow-sm cursor-pointer mb-stack-lg"
        >
          Continuer mon activité en cours
          <span className="material-symbols-outlined">arrow_forward</span>
        </button>

        {/* Encouragement Banner */}
        <div className="bg-secondary-container rounded-xl p-gutter flex items-center gap-gutter border border-on-secondary-container/10">
          <span className="material-symbols-outlined text-secondary text-4xl fill-1" data-icon="stars">
            stars
          </span>
          <div>
            <p className="text-[14px] leading-[20px] font-semibold text-on-secondary-container">
              Statut Excellent
            </p>
            <p className="text-[16px] leading-[24px] text-on-secondary-container">
              Votre rendement estimé est 15% supérieur à la saison dernière !
            </p>
          </div>
        </div>
      </main>
    </div>
  );
};
