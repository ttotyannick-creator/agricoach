/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  CROPS_DATA,
  CROP_IMAGES,
  getCropAdaptation,
  getCropByIdWithProgress,
} from '../data/agronomyData';
import { Crop, CropCategory, UserProfile } from '../types/agricoach';

interface CropsScreenProps {
  userProfile: UserProfile;
  selectedCropId: string;
  onSelectCrop: (cropId: string) => void;
  onGoToActivities: () => void;
  onReadAloud?: (text: string) => void;
}

export const CropsScreen: React.FC<CropsScreenProps> = ({
  userProfile,
  selectedCropId,
  onSelectCrop,
  onGoToActivities,
  onReadAloud,
}) => {
  // Par défaut, afficher TOUTES les cultures (comme demandé impérativement par l'utilisateur)
  const [viewMode, setViewMode] = useState<'catalog' | 'cycle'>('catalog');
  const [displayStyle, setDisplayStyle] = useState<'grid' | 'cards'>('grid');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('Toutes');
  const [viewingCropId, setViewingCropId] = useState<string | null>(null);

  const activeCrop = getCropByIdWithProgress(viewingCropId || selectedCropId, userProfile);
  const currentAdaptation = getCropAdaptation(activeCrop, userProfile.locality);

  // Groupement par catégories pour la vue grille conforme à Image_15
  const categoriesList: { name: CropCategory; icon: string }[] = [
    { name: 'Céréales', icon: 'grain' },
    { name: 'Tubercules', icon: 'restaurant' },
    { name: 'Légumineuses', icon: 'psychology_alt' },
    { name: 'Maraîchage', icon: 'yard' },
    { name: 'Autres', icon: 'category' },
  ];

  const filterChips = ['Toutes', 'Céréales', 'Tubercules', 'Maraîchage', 'Légumineuses', 'Autres'];

  const filteredCrops = CROPS_DATA.filter((c) => {
    const matchesSearch = c.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory =
      selectedCategory === 'Toutes' || c.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  // Calcul progression dynamique du cycle (commence strictement à 0% si aucune activité validée)
  const totalSteps = activeCrop.steps.length || 6;
  const completedStepsList = activeCrop.steps.filter((s) => s.completed);
  const completedStepsCount = completedStepsList.length;
  const uncompletedStepsList = activeCrop.steps.filter((s) => !s.completed);
  const progressPercent =
    totalSteps > 0 ? Math.round((completedStepsCount / totalSteps) * 100) : 0;

  const radius = 54;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progressPercent / 100) * circumference;

  const handleOpenCropDetails = (crop: Crop) => {
    setViewingCropId(crop.id);
    onSelectCrop(crop.id);
    setViewMode('cycle');
  };

  return (
    <div className="pb-32 max-w-md mx-auto">
      {/* Top App Bar */}
      <header className="bg-surface border-b border-outline-variant flex justify-between items-center px-margin-mobile h-[56px] w-full sticky top-0 z-40 bg-opacity-95 backdrop-blur-sm">
        <div className="flex items-center gap-base">
          {viewMode === 'cycle' && (
            <button
              onClick={() => setViewMode('catalog')}
              className="material-symbols-outlined text-primary cursor-pointer active:scale-95 transition-transform mr-1"
              title="Retour aux cultures"
            >
              arrow_back
            </button>
          )}
          <div className="w-8 h-8 rounded-full bg-secondary-container flex items-center justify-center overflow-hidden border border-outline-variant">
            {CROP_IMAGES.farmerSmall ? (
              <img src={CROP_IMAGES.farmerSmall} alt="Avatar" className="w-full h-full object-cover" />
            ) : (
              <span className="material-symbols-outlined text-on-secondary-container text-[20px]">
                person
              </span>
            )}
          </div>
          <h1 className="text-[22px] leading-[28px] font-bold text-primary">AgriCoach</h1>
        </div>

        <div className="flex items-center gap-2">
          {viewMode === 'catalog' && (
            <button
              onClick={() => setDisplayStyle(displayStyle === 'grid' ? 'cards' : 'grid')}
              className="p-1.5 text-primary hover:bg-surface-container rounded-lg cursor-pointer"
              title={displayStyle === 'grid' ? 'Vue catalogue liste' : 'Vue par catégories'}
            >
              <span className="material-symbols-outlined text-[20px]">
                {displayStyle === 'grid' ? 'view_agenda' : 'grid_view'}
              </span>
            </button>
          )}
          <button className="material-symbols-outlined text-primary active:scale-95 transition-transform p-1">
            notifications
          </button>
        </div>
      </header>

      {/* ============================================================== */}
      {/* VUE PRINCIPALE : TOUTES LES CULTURES (Image_15_626d1e84 & Image_1) */}
      {/* ============================================================== */}
      {viewMode === 'catalog' ? (
        <main className="px-margin-mobile pt-stack-md">
          {/* Titre et sous-titre conformes à la maquette */}
          <header className="mb-4">
            <h2 className="text-[22px] leading-[28px] font-bold text-on-surface">
              {displayStyle === 'grid' ? 'Choisissez votre culture' : 'Catalogue des cultures'}
            </h2>
            <p className="text-[16px] leading-[24px] text-on-surface-variant">
              Sélectionnez la culture que vous souhaitez planter pour obtenir des conseils personnalisés.
            </p>
          </header>

          {/* Barre de recherche */}
          <div className="relative flex items-center mb-4">
            <span className="material-symbols-outlined absolute left-4 text-outline text-[20px]">
              search
            </span>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Rechercher une culture..."
              className="w-full h-[48px] pl-12 pr-4 bg-surface-container-lowest border border-outline-variant rounded-xl focus:border-primary focus:outline-none text-[16px] shadow-xs"
            />
          </div>

          {/* Filtres par catégories si mode liste */}
          {displayStyle === 'cards' && (
            <div className="flex gap-2 overflow-x-auto pb-3 mb-4 scrollbar-none">
              {filterChips.map((cat) => {
                const isCatActive = selectedCategory === cat;
                return (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-4 py-1.5 rounded-full text-[14px] font-semibold whitespace-nowrap transition-all cursor-pointer ${
                      isCatActive
                        ? 'bg-primary text-on-primary'
                        : 'bg-surface-container-lowest border border-outline text-on-surface hover:bg-surface-container-low'
                    }`}
                  >
                    {cat}
                  </button>
                );
              })}
            </div>
          )}

          {/* 1. DISPOSITION EN GRILLE PAR CATÉGORIES (Conforme à Image_15_626d1e84.png) */}
          {displayStyle === 'grid' && !searchQuery && (
            <div className="space-y-6">
              {categoriesList.map((cat) => {
                const cropsInCat = CROPS_DATA.filter((c) => c.category === cat.name);
                if (cropsInCat.length === 0) return null;

                return (
                  <section key={cat.name} className="space-y-3">
                    <div className="flex items-center gap-2">
                      <span className="material-symbols-outlined text-primary text-[22px]">
                        {cat.icon}
                      </span>
                      <h3 className="text-[20px] leading-[28px] font-bold text-on-surface">
                        {cat.name}
                      </h3>
                    </div>

                    <div className="grid grid-cols-2 gap-3.5">
                      {cropsInCat.map((crop) => {
                        const isSelected = crop.id === selectedCropId;
                        return (
                          <div
                            key={crop.id}
                            onClick={() => handleOpenCropDetails(crop)}
                            className={`bg-surface-container-lowest rounded-2xl overflow-hidden border border-outline-variant shadow-xs active:scale-95 transition-all cursor-pointer flex flex-col hover:border-primary relative ${
                              isSelected ? 'ring-2 ring-primary' : ''
                            }`}
                          >
                            <div className="h-32 w-full overflow-hidden bg-surface-container">
                              <img
                                src={crop.image}
                                alt={crop.name}
                                className="w-full h-full object-cover"
                                loading="lazy"
                              />
                            </div>
                            <div className="p-3 text-center flex-grow flex items-center justify-center">
                              <span className="font-bold text-[16px] text-on-surface">
                                {crop.name}
                              </span>
                            </div>
                            {isSelected && (
                              <div className="absolute top-2 right-2 bg-primary text-white rounded-full p-0.5 shadow-sm">
                                <span className="material-symbols-outlined text-[14px]">check</span>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </section>
                );
              })}
            </div>
          )}

          {/* 2. DISPOSITION EN CARTES DÉTAILLÉES (Conforme à Image_1_9a16b059.png) */}
          {(displayStyle === 'cards' || searchQuery) && (
            <div className="space-y-4">
              {filteredCrops.length === 0 ? (
                <div className="text-center py-12 text-on-surface-variant">
                  <span className="material-symbols-outlined text-4xl mb-2 text-outline">
                    search_off
                  </span>
                  <p>Aucune culture ne correspond à votre recherche.</p>
                </div>
              ) : (
                filteredCrops.map((crop) => {
                  const isCurrentlySelected = crop.id === selectedCropId;
                  const adaptation = getCropAdaptation(crop, userProfile.locality);

                  return (
                    <article
                      key={crop.id}
                      className="bg-surface-container-lowest border border-outline-variant rounded-2xl overflow-hidden shadow-xs hover:border-primary transition-colors"
                    >
                      <div className="h-44 w-full relative overflow-hidden bg-surface-container">
                        <img
                          src={crop.image}
                          alt={crop.name}
                          className="w-full h-full object-cover"
                          loading="lazy"
                        />
                        {crop.isPrincipal && (
                          <span className="absolute top-3 right-3 bg-primary text-on-primary text-[12px] font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                            Principal
                          </span>
                        )}
                        {isCurrentlySelected && (
                          <span className="absolute top-3 left-3 bg-primary text-on-primary text-[12px] font-bold px-3 py-1 rounded-full flex items-center gap-1 shadow-sm">
                            <span className="material-symbols-outlined text-[14px]">check</span>
                            En cours
                          </span>
                        )}
                      </div>
                      <div className="p-4 flex flex-col gap-2">
                        <div className="flex items-center justify-between">
                          <h3 className="text-[20px] font-bold text-on-surface">{crop.name}</h3>
                          <span
                            className={`text-xs px-2.5 py-0.5 rounded-full font-semibold ${
                              adaptation.level === 'ADAPTEE'
                                ? 'bg-primary-container text-on-primary-container'
                                : 'bg-secondary-container text-on-secondary-container'
                            }`}
                          >
                            {adaptation.levelLabel}
                          </span>
                        </div>
                        <p className="text-[14px] text-on-surface-variant line-clamp-2">
                          {crop.description}
                        </p>
                        <div className="flex items-center justify-between pt-2 border-t border-outline-variant/60 mt-1">
                          <span className="text-[14px] text-on-surface-variant flex items-center gap-1">
                            <span className="material-symbols-outlined text-[18px]">
                              calendar_today
                            </span>
                            {crop.duration}
                          </span>
                          <button
                            onClick={() => handleOpenCropDetails(crop)}
                            className="px-4 py-2 bg-primary text-on-primary rounded-lg text-[14px] font-bold flex items-center gap-1 active:scale-95 transition-all cursor-pointer shadow-xs"
                          >
                            Détails
                            <span className="material-symbols-outlined text-[16px]">
                              arrow_forward
                            </span>
                          </button>
                        </div>
                      </div>
                    </article>
                  );
                })
              )}
            </div>
          )}

          {/* Bouton d'action flottant (+) conforme à Image_15 */}
          <div className="fixed bottom-20 right-6 z-40 max-w-md">
            <button
              onClick={() => {
                if (onReadAloud) {
                  onReadAloud('Sélectionnez la culture vivrière que vous souhaitez cultiver.');
                }
              }}
              className="w-14 h-14 bg-primary text-on-primary rounded-2xl flex items-center justify-center shadow-lg active:scale-90 transition-transform cursor-pointer"
              title="Ajouter ou explorer une culture"
            >
              <span className="material-symbols-outlined text-3xl">add</span>
            </button>
          </div>
        </main>
      ) : (
        /* ============================================================== */
        /* VUE 2 : FICHE CULTURE ET SUIVI DE CYCLE (Image_4_11433018.html) */
        /* ============================================================== */
        <main className="px-margin-mobile mt-stack-lg animate-fade-in">
          {/* Bannière de sélection de la culture en haut de fiche */}
          <div className="mb-4 bg-surface-container-low p-3.5 rounded-xl border border-outline-variant flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img
                src={activeCrop.image}
                alt={activeCrop.name}
                className="w-12 h-12 rounded-lg object-cover border border-outline-variant"
              />
              <div>
                <h3 className="font-bold text-primary text-[18px]">{activeCrop.name}</h3>
                <p className="text-xs text-on-surface-variant">
                  {activeCrop.category} • {activeCrop.duration}
                </p>
              </div>
            </div>
            <button
              onClick={() => setViewMode('catalog')}
              className="text-xs font-semibold px-3 py-1.5 rounded-lg border border-primary text-primary hover:bg-primary/5 active:scale-95"
            >
              Changer
            </button>
          </div>

          {/* Adaptation agronomique à la localité */}
          <section className="mb-stack-lg bg-surface-container-lowest border border-outline-variant rounded-xl p-4 shadow-sm space-y-3">
            <div className="flex items-center justify-between border-b border-outline-variant/60 pb-2">
              <h4 className="font-bold text-[16px] text-on-surface flex items-center gap-1.5">
                <span className="material-symbols-outlined text-primary text-[20px]">
                  location_on
                </span>
                Adaptation à {userProfile.locality || 'votre localité'}
              </h4>
              <div className="flex items-center gap-2">
                <span
                  className={`text-xs px-2.5 py-0.5 rounded-full font-bold ${
                    currentAdaptation.level === 'ADAPTEE'
                      ? 'bg-primary-container text-on-primary-container'
                      : 'bg-secondary-container text-on-secondary-container'
                  }`}
                >
                  {currentAdaptation.levelLabel}
                </span>
                {onReadAloud && (
                  <button
                    onClick={() =>
                      onReadAloud(
                        `Culture de ${activeCrop.name} à ${userProfile.locality || 'votre localité'}. Évaluation : ${currentAdaptation.levelLabel}. ${currentAdaptation.reasons}. Sol et climat : ${currentAdaptation.climateAndSoil}. Conseil pour le sol : ${currentAdaptation.soilAdvice}`
                      )
                    }
                    className="p-1 text-primary hover:bg-primary/10 rounded-full cursor-pointer"
                    title="Écouter les explications agronomiques"
                  >
                    <span className="material-symbols-outlined text-[18px]">volume_up</span>
                  </button>
                )}
              </div>
            </div>

            <p className="text-[14px] text-on-surface-variant leading-relaxed">
              {currentAdaptation.reasons}
            </p>

            <div className="text-xs bg-surface-container-low p-2.5 rounded-lg border border-outline-variant flex items-center justify-between">
              <div>
                <span className="font-bold text-primary">Sol & Climat requis : </span>
                <span className="text-on-surface-variant">{currentAdaptation.climateAndSoil}</span>
              </div>
              {onReadAloud && (
                <button
                  onClick={() => onReadAloud(`Sol et climat pour ${activeCrop.name} : ${currentAdaptation.climateAndSoil}`)}
                  className="p-1 text-primary hover:bg-primary/10 rounded-full shrink-0 ml-1"
                >
                  <span className="material-symbols-outlined text-[16px]">volume_up</span>
                </button>
              )}
            </div>

            <div className="text-xs bg-surface-container-low p-2.5 rounded-lg border border-outline-variant flex items-center justify-between">
              <div>
                <span className="font-bold text-secondary">Conseil sol & fertilisation : </span>
                <span className="text-on-surface-variant">{currentAdaptation.soilAdvice}</span>
              </div>
              {onReadAloud && (
                <button
                  onClick={() => onReadAloud(`Conseil sol pour ${activeCrop.name} : ${currentAdaptation.soilAdvice}`)}
                  className="p-1 text-secondary hover:bg-secondary/10 rounded-full shrink-0 ml-1"
                >
                  <span className="material-symbols-outlined text-[16px]">volume_up</span>
                </button>
              )}
            </div>
          </section>

          {/* Hero Progress Card (Conforme à Image_4) */}
          <section className="bg-surface-container-lowest border border-outline-variant rounded-xl p-gutter shadow-sm mb-stack-lg overflow-hidden relative">
            <div className="flex flex-col items-center justify-center py-stack-md relative z-10">
              <div className="relative flex items-center justify-center mb-base">
                <svg className="w-32 h-32">
                  <circle
                    className="text-surface-container stroke-current"
                    cx="64"
                    cy="64"
                    fill="transparent"
                    r={radius}
                    strokeWidth="12"
                  />
                  <circle
                    className="text-primary stroke-current progress-ring__circle"
                    cx="64"
                    cy="64"
                    fill="transparent"
                    r={radius}
                    strokeDasharray={circumference}
                    strokeDashoffset={strokeDashoffset}
                    strokeLinecap="round"
                    strokeWidth="12"
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-[32px] leading-[40px] font-bold text-primary">
                    {progressPercent}%
                  </span>
                  <span className="text-[14px] leading-[20px] font-semibold text-on-surface-variant">
                    Terminé
                  </span>
                </div>
              </div>
              <h2 className="text-[20px] leading-[28px] font-semibold text-on-surface text-center px-4">
                Cycle du {activeCrop.name} : En bonne voie !
              </h2>
              <p className="text-[16px] leading-[24px] text-on-surface-variant text-center mt-base">
                Plus que quelques étapes avant la récolte.
              </p>
            </div>
            <div className="absolute top-0 right-0 opacity-10 -mr-8 -mt-8 pointer-events-none">
              <span className="material-symbols-outlined" style={{ fontSize: '160px' }}>
                eco
              </span>
            </div>
          </section>

          {/* Étapes restantes */}
          <div className="space-y-stack-lg">
            <section>
              <div className="flex items-center justify-between mb-stack-md">
                <div className="flex items-center gap-base">
                  <span className="material-symbols-outlined text-secondary" data-icon="pending_actions">
                    pending_actions
                  </span>
                  <h3 className="text-[20px] leading-[28px] font-semibold text-on-surface">
                    Étapes restantes
                  </h3>
                </div>
              </div>

              <div className="space-y-base">
                {uncompletedStepsList.length === 0 ? (
                  <div className="bg-surface-container-low rounded-xl p-stack-md border border-outline-variant text-center">
                    <p className="text-[15px] font-bold text-primary">
                      Toutes les étapes du cycle ont été validées avec succès !
                    </p>
                  </div>
                ) : (
                  uncompletedStepsList.slice(0, 2).map((step, idx) => {
                    const isNextActive = idx === 0;
                    return (
                      <div
                        key={step.id}
                        onClick={isNextActive ? onGoToActivities : undefined}
                        className={`rounded-xl p-stack-md flex items-center gap-gutter transition-all ${
                          isNextActive
                            ? 'bg-surface border-2 border-primary-container active:scale-[0.98] cursor-pointer shadow-xs hover:border-primary'
                            : 'bg-surface border border-outline-variant opacity-80'
                        }`}
                      >
                        <div
                          className={`w-12 h-12 rounded-full flex items-center justify-center shrink-0 ${
                            isNextActive
                              ? 'bg-primary-container text-on-primary-container'
                              : 'bg-surface-container text-on-surface-variant border border-outline-variant'
                          }`}
                        >
                          <span
                            className="material-symbols-outlined"
                            data-icon={isNextActive ? 'water_drop' : 'agriculture'}
                          >
                            {isNextActive ? 'water_drop' : 'agriculture'}
                          </span>
                        </div>
                        <div className="flex-grow">
                          <p
                            className={`text-[14px] leading-[20px] font-semibold ${
                              isNextActive ? 'text-primary' : 'text-on-surface-variant'
                            }`}
                          >
                            {isNextActive ? "À faire maintenant" : `Étape ${step.stepNumber}`}
                          </p>
                          <p className="text-[18px] leading-[26px] font-bold">{step.title}</p>
                          <p className="text-[16px] leading-[24px] text-on-surface-variant">
                            {step.durationText}
                          </p>
                        </div>
                        <span
                          className="material-symbols-outlined text-outline"
                          data-icon={isNextActive ? 'chevron_right' : 'lock'}
                        >
                          {isNextActive ? 'chevron_right' : 'lock'}
                        </span>
                      </div>
                    );
                  })
                )}
              </div>
            </section>

            {/* Historique validé */}
            <section>
              <div className="flex items-center gap-base mb-stack-md">
                <span className="material-symbols-outlined text-primary" data-icon="task_alt">
                  task_alt
                </span>
                <h3 className="text-[20px] leading-[28px] font-semibold text-on-surface">
                  Historique validé
                </h3>
              </div>

              {completedStepsList.length === 0 ? (
                <div className="bg-surface-container-low rounded-xl p-stack-md border border-outline-variant text-center">
                  <p className="text-[14px] text-on-surface-variant">
                    Aucune activité validée pour le moment. Réalisez votre première étape pour commencer à faire progresser votre culture.
                  </p>
                </div>
              ) : (
                <div className="space-y-0 border-l-2 border-primary ml-6 pl-6 relative">
                  {completedStepsList.map((step) => (
                    <div key={step.id} className="relative pb-stack-lg last:pb-0">
                      <div className="absolute -left-[33px] top-0 bg-primary rounded-full w-4 h-4 flex items-center justify-center ring-4 ring-background">
                        <span className="material-symbols-outlined text-white text-[10px] fill-1">
                          check
                        </span>
                      </div>
                      <div className="bg-surface-container-low rounded-xl p-stack-md border border-outline-variant">
                        <div className="flex justify-between items-start">
                          <div>
                            <p className="text-[18px] leading-[26px] font-bold">{step.title}</p>
                            <p className="text-[16px] leading-[24px] text-on-surface-variant">
                              {step.completedDate || 'Validé avec succès'}
                            </p>
                          </div>
                          <div className="w-14 h-14 rounded-lg overflow-hidden border border-outline-variant">
                            <img
                              className="w-full h-full object-cover"
                              alt={step.title}
                              src={step.photoProof || step.image}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </section>
          </div>

          {/* Bouton d'action direct vers les activités */}
          <div className="mt-stack-lg">
            <button
              onClick={onGoToActivities}
              className="w-full h-[56px] bg-primary text-on-primary rounded-xl font-bold text-[18px] flex items-center justify-center gap-base active:scale-95 transition-transform shadow-sm cursor-pointer"
            >
              Aller aux activités de cette culture
              <span className="material-symbols-outlined">arrow_forward</span>
            </button>
          </div>

          {/* Encouragement Banner */}
          <div className="mt-stack-lg bg-secondary-container rounded-xl p-gutter flex items-center gap-gutter border border-on-secondary-container/10">
            <span className="material-symbols-outlined text-secondary text-4xl fill-1" data-icon="stars">
              stars
            </span>
            <div>
              <p className="text-[14px] leading-[20px] font-semibold text-on-secondary-container">
                Statut Excellent
              </p>
              <p className="text-[16px] leading-[24px] text-on-secondary-container">
                Votre rendement estimé est 15% supérieur à la saison dernière !
              </p>
            </div>
          </div>
        </main>
      )}
    </div>
  );
};
