/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { CROP_IMAGES, getCropById } from '../data/agronomyData';
import { UserProfile } from '../types/agricoach';

interface ProfileScreenProps {
  userProfile: UserProfile;
  onUpdateProfile: (updated: Partial<UserProfile>) => void;
  onLogout: () => void;
  onReadAloud?: (text: string) => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  userProfile,
  onUpdateProfile,
  onLogout,
  onReadAloud,
}) => {
  const [isEditingName, setIsEditingName] = useState(false);
  const [isEditingLocality, setIsEditingLocality] = useState(false);
  const [tempName, setTempName] = useState(userProfile.name);
  const [tempLocality, setTempLocality] = useState(userProfile.locality);
  const [showFaqModal, setShowFaqModal] = useState(false);

  const activeCrop = getCropById(userProfile.cropSelectedId);

  const handleSaveName = () => {
    if (tempName.trim()) {
      onUpdateProfile({ name: tempName.trim() });
      setIsEditingName(false);
    }
  };

  const handleSaveLocality = () => {
    if (tempLocality.trim()) {
      onUpdateProfile({ locality: tempLocality.trim() });
      setIsEditingLocality(false);
    }
  };

  return (
    <div className="pb-32 max-w-md mx-auto">
      {/* TopAppBar */}
      <header className="bg-surface border-b border-outline-variant flex justify-between items-center px-margin-mobile h-[56px] w-full sticky top-0 z-40 bg-opacity-95 backdrop-blur-sm">
        <h1 className="text-[22px] leading-[28px] font-bold text-primary">AgriCoach</h1>
        <div className="flex items-center gap-base">
          <span className="material-symbols-outlined text-primary cursor-pointer active:scale-95 transition-transform">
            notifications
          </span>
          <div className="w-8 h-8 rounded-full overflow-hidden border border-outline-variant">
            <img
              alt="Profil de l'agriculteur"
              className="w-full h-full object-cover"
              src={CROP_IMAGES.farmerSmall}
            />
          </div>
        </div>
      </header>

      <main className="px-margin-mobile pt-stack-lg max-w-lg mx-auto">
        {/* Profile Hero Section */}
        <section className="flex flex-col items-center mb-stack-lg">
          <div className="relative mb-stack-md">
            <div className="w-32 h-32 rounded-full border-4 border-primary p-1 bg-surface-container-lowest overflow-hidden shadow-sm">
              <img
                alt="Avatar Agriculteur"
                className="w-full h-full object-cover rounded-full"
                src={CROP_IMAGES.farmerAvatar}
              />
            </div>
            <button
              onClick={() => {
                if (onReadAloud) onReadAloud('Option de mise à jour de la photo de profil.');
              }}
              className="absolute bottom-0 right-0 bg-primary text-on-primary w-10 h-10 rounded-full flex items-center justify-center shadow-sm active:scale-90 transition-all cursor-pointer"
              title="Changer la photo"
            >
              <span className="material-symbols-outlined text-[20px]">photo_camera</span>
            </button>
          </div>
          <h2 className="text-[22px] leading-[28px] font-bold text-on-surface">
            {userProfile.name || 'Koffi Kouamé'}
          </h2>
          <p className="text-[16px] leading-[24px] text-on-surface-variant">
            Producteur de {activeCrop.name}
          </p>
        </section>

        {/* Information Section */}
        <div className="space-y-stack-md mb-stack-lg">
          <div className="bg-surface-container-lowest border border-[#D2B48C] rounded-xl p-stack-md shadow-xs">
            {/* Nom complet */}
            <div className="flex flex-col space-y-base">
              <label className="text-[14px] leading-[20px] font-semibold text-on-surface-variant">
                Nom complet
              </label>
              {isEditingName ? (
                <div className="flex gap-2 items-center">
                  <input
                    type="text"
                    value={tempName}
                    onChange={(e) => setTempName(e.target.value)}
                    className="flex-grow px-3 py-1.5 border border-primary rounded-lg text-sm"
                  />
                  <button
                    onClick={handleSaveName}
                    className="px-3 py-1.5 bg-primary text-white text-xs font-bold rounded-lg"
                  >
                    OK
                  </button>
                </div>
              ) : (
                <div className="flex justify-between items-center">
                  <span className="text-[20px] leading-[28px] font-semibold text-on-surface">
                    {userProfile.name || 'Koffi Kouamé'}
                  </span>
                  <button
                    onClick={() => {
                      setTempName(userProfile.name);
                      setIsEditingName(true);
                    }}
                    className="text-primary text-[14px] font-semibold flex items-center gap-1 active:scale-95 transition-transform cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-[18px]">edit</span>
                    Modifier
                  </button>
                </div>
              )}
            </div>

            <div className="h-[1px] bg-outline-variant my-base"></div>

            {/* Localité */}
            <div className="flex flex-col space-y-base">
              <label className="text-[14px] leading-[20px] font-semibold text-on-surface-variant">
                Localité
              </label>
              {isEditingLocality ? (
                <div className="flex gap-2 items-center">
                  <input
                    type="text"
                    value={tempLocality}
                    onChange={(e) => setTempLocality(e.target.value)}
                    className="flex-grow px-3 py-1.5 border border-primary rounded-lg text-sm"
                  />
                  <button
                    onClick={handleSaveLocality}
                    className="px-3 py-1.5 bg-primary text-white text-xs font-bold rounded-lg"
                  >
                    OK
                  </button>
                </div>
              ) : (
                <div className="flex justify-between items-center">
                  <span className="text-[20px] leading-[28px] font-semibold text-on-surface">
                    {userProfile.locality ? `${userProfile.locality}, Côte d'Ivoire` : "Soubré, Côte d'Ivoire"}
                  </span>
                  <button
                    onClick={() => {
                      setTempLocality(userProfile.locality);
                      setIsEditingLocality(true);
                    }}
                    className="text-primary text-[14px] font-semibold flex items-center gap-1 active:scale-95 transition-transform cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-[18px]">location_on</span>
                    Modifier
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Settings Section */}
          <div className="bg-surface-container-lowest border border-[#D2B48C] rounded-xl p-stack-md space-y-stack-md shadow-xs">
            <h3 className="text-[20px] leading-[28px] font-semibold text-on-surface">Paramètres</h3>

            {/* Langue */}
            <div className="flex items-center justify-between py-base cursor-pointer">
              <div className="flex items-center gap-stack-md">
                <div className="w-10 h-10 bg-secondary-container text-on-secondary-container rounded-lg flex items-center justify-center">
                  <span className="material-symbols-outlined">language</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-[14px] leading-[20px] font-semibold text-on-surface">Langue</span>
                  <span className="text-[16px] leading-[24px] text-on-surface-variant">
                    Français (Côte d'Ivoire)
                  </span>
                </div>
              </div>
              <span className="material-symbols-outlined text-outline">chevron_right</span>
            </div>

            {/* FAQ */}
            <div
              onClick={() => setShowFaqModal(true)}
              className="flex items-center justify-between py-base cursor-pointer hover:bg-surface-container-low rounded-lg transition-colors p-1"
            >
              <div className="flex items-center gap-stack-md">
                <div className="w-10 h-10 bg-secondary-container text-on-secondary-container rounded-lg flex items-center justify-center">
                  <span className="material-symbols-outlined">help</span>
                </div>
                <span className="text-[14px] leading-[20px] font-semibold text-on-surface">
                  Assistance &amp; FAQ
                </span>
              </div>
              <span className="material-symbols-outlined text-outline">chevron_right</span>
            </div>

            {/* Assistant vocal - Activer / Désactiver */}
            <div className="flex items-center justify-between py-base border-t border-outline-variant/60 pt-base">
              <div className="flex items-center gap-stack-md">
                <div
                  className={`w-10 h-10 ${
                    userProfile.isVoiceAssistantEnabled !== false
                      ? 'bg-primary-container text-on-primary-container'
                      : 'bg-surface-container text-outline'
                  } rounded-lg flex items-center justify-center transition-colors`}
                >
                  <span className="material-symbols-outlined">
                    {userProfile.isVoiceAssistantEnabled !== false ? 'mic' : 'mic_off'}
                  </span>
                </div>
                <div className="flex flex-col">
                  <span className="text-[14px] leading-[20px] font-semibold text-on-surface">
                    Assistant vocal
                  </span>
                  <span className="text-[14px] text-on-surface-variant">
                    {userProfile.isVoiceAssistantEnabled !== false
                      ? 'Activé (mains libres)'
                      : 'Désactivé'}
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  const newState = !(userProfile.isVoiceAssistantEnabled !== false);
                  onUpdateProfile({ isVoiceAssistantEnabled: newState });
                  if (onReadAloud && newState) {
                    onReadAloud("L'assistant vocal est activé.");
                  }
                }}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${
                  userProfile.isVoiceAssistantEnabled !== false ? 'bg-primary' : 'bg-outline-variant'
                }`}
                title={
                  userProfile.isVoiceAssistantEnabled !== false
                    ? 'Désactiver l’assistant vocal'
                    : 'Activer l’assistant vocal'
                }
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    userProfile.isVoiceAssistantEnabled !== false ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>

        {/* Logout Button */}
        <button
          onClick={onLogout}
          className="w-full h-[48px] bg-error-container text-on-error-container rounded-xl flex items-center justify-center gap-base font-bold text-[18px] active:scale-95 transition-all mb-stack-lg cursor-pointer"
        >
          <span className="material-symbols-outlined">logout</span>
          Se déconnecter
        </button>

        <p className="text-center text-[14px] leading-[20px] font-semibold text-outline-variant mb-stack-lg">
          Version 1.2.0
        </p>
      </main>

      {/* Modal FAQ */}
      {showFaqModal && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-surface rounded-2xl p-6 max-w-md w-full border border-outline-variant shadow-2xl max-h-[80vh] overflow-y-auto space-y-4">
            <div className="flex items-center justify-between border-b pb-3 border-outline-variant">
              <h4 className="font-bold text-lg text-primary flex items-center gap-2">
                <span className="material-symbols-outlined">help</span>
                Questions fréquentes
              </h4>
              <button
                onClick={() => setShowFaqModal(false)}
                className="p-1 rounded-full hover:bg-surface-container"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>
            <div className="space-y-3 text-sm text-on-surface-variant">
              <div>
                <p className="font-bold text-on-surface">Comment fonctionne l'assistant vocal ?</p>
                <p>
                  AgriCoach vous écoute dès que vous arrivez sur l'écran. Vous pouvez lui poser
                  n'importe quelle question sur vos plants, le sol, l'eau ou la récolte sans retoucher
                  le microphone.
                </p>
              </div>
              <div>
                <p className="font-bold text-on-surface">
                  Mes données sont-elles conservées sans Internet ?
                </p>
                <p>
                  Oui, vos étapes validées, vos photos et vos réglages sont sauvegardés sur votre
                  téléphone en local.
                </p>
              </div>
              <div>
                <p className="font-bold text-on-surface">
                  Comment changer de localité ou de culture ?
                </p>
                <p>
                  Vous pouvez modifier votre localité directement ici, ou vous rendre dans l'onglet
                  « Cultures » pour en sélectionner une nouvelle.
                </p>
              </div>
            </div>
            <button
              onClick={() => setShowFaqModal(false)}
              className="w-full py-2.5 bg-primary text-on-primary rounded-xl font-bold"
            >
              Fermer
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
