/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { CROP_IMAGES, getCropByIdWithProgress } from '../data/agronomyData';
import { UserProfile } from '../types/agricoach';

interface HomeScreenProps {
  userProfile: UserProfile;
  onOpenWeather: () => void;
  onOpenCalendar: () => void;
  onOpenProgression: () => void;
  onGoToActivities: () => void;
  onReadAloud?: (text: string) => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  userProfile,
  onOpenWeather,
  onOpenCalendar,
  onOpenProgression,
  onGoToActivities,
  onReadAloud,
}) => {
  const [adviceDone, setAdviceDone] = useState(false);
  const [showNotificationModal, setShowNotificationModal] = useState(false);

  const activeCrop = getCropByIdWithProgress(userProfile.cropSelectedId, userProfile);
  const localityDisplay = userProfile.locality || 'Yamoussoukro';
  const completedSteps = activeCrop.steps.filter((s) => s.completed).length;
  const totalSteps = activeCrop.steps.length || 6;
  const progressPercent = Math.round((completedSteps / totalSteps) * 100);

  const adviceText =
    "C'est le bon moment pour préparer vos plants. L'humidité du sol est favorable et le soleil sera propice aux travaux cet après-midi.";

  return (
    <div className="pb-32 max-w-md mx-auto">
      {/* Top App Bar */}
      <header className="bg-surface border-b border-outline-variant flex justify-between items-center px-margin-mobile h-[56px] w-full sticky top-0 z-40 bg-opacity-95 backdrop-blur-sm">
        <div className="flex items-center gap-base">
          <div className="w-8 h-8 rounded-full overflow-hidden bg-secondary-container flex items-center justify-center border border-outline-variant">
            {CROP_IMAGES.farmerSmall ? (
              <img src={CROP_IMAGES.farmerSmall} alt="Avatar" className="w-full h-full object-cover" />
            ) : (
              <span className="material-symbols-outlined text-on-secondary-container fill-1 text-[20px]">
                account_circle
              </span>
            )}
          </div>
          <h1 className="text-[22px] leading-[28px] font-bold text-primary">AgriCoach</h1>
        </div>
        <button
          onClick={() => setShowNotificationModal(true)}
          className="active:scale-95 transition-transform hover:bg-surface-container-low p-2 rounded-full cursor-pointer"
          title="Notifications"
        >
          <span className="material-symbols-outlined text-primary">notifications</span>
        </button>
      </header>

      <main className="px-margin-mobile pt-stack-md flex flex-col gap-stack-lg">
        {/* En-tête de bienvenue personnalisé */}
        <section className="flex items-center justify-between">
          <div>
            <h2 className="text-[22px] leading-[28px] font-bold text-on-surface">
              Bonjour, {userProfile.name || 'Cher agriculteur'}
            </h2>
            <p className="text-[14px] leading-[20px] text-on-surface-variant flex items-center gap-1 mt-0.5">
              <span className="material-symbols-outlined text-primary text-[16px]">location_on</span>
              {localityDisplay}, Côte d'Ivoire • Culture : {activeCrop.name}
            </p>
          </div>
          {onReadAloud && (
            <button
              onClick={() =>
                onReadAloud(
                  `Bonjour ${userProfile.name}. Bienvenue sur AgriCoach à ${localityDisplay}. Votre culture de ${activeCrop.name} est à ${progressPercent} pour cent de réalisation.`
                )
              }
              className="p-2 text-primary hover:bg-primary/10 rounded-full"
              title="Écouter le résumé d'accueil"
            >
              <span className="material-symbols-outlined text-[20px]">volume_up</span>
            </button>
          )}
        </section>

        {/* ============================================================== */}
        {/* LES 3 RACCOURCIS VISUELS ESSENTIELS : MÉTÉO, CALENDRIER, PROGRESSION */}
        {/* ============================================================== */}
        <section className="grid grid-cols-3 gap-2.5">
          {/* A. Raccourci Météo */}
          <button
            onClick={onOpenWeather}
            className="bg-surface-container-lowest border border-outline-variant rounded-2xl p-3 flex flex-col items-center justify-center gap-1.5 shadow-xs hover:border-primary active:scale-95 transition-all cursor-pointer text-center"
          >
            <div className="w-11 h-11 rounded-full bg-[#FFF3E0] flex items-center justify-center text-[#F57C00]">
              <span className="material-symbols-outlined text-[26px] fill-1">wb_sunny</span>
            </div>
            <span className="font-bold text-[13px] text-on-surface">Météo</span>
            <span className="text-[11px] text-on-surface-variant leading-tight">28°C Ensoleillé</span>
          </button>

          {/* B. Raccourci Calendrier */}
          <button
            onClick={onOpenCalendar}
            className="bg-surface-container-lowest border border-outline-variant rounded-2xl p-3 flex flex-col items-center justify-center gap-1.5 shadow-xs hover:border-primary active:scale-95 transition-all cursor-pointer text-center"
          >
            <div className="w-11 h-11 rounded-full bg-secondary-container flex items-center justify-center text-secondary">
              <span className="material-symbols-outlined text-[26px]">calendar_month</span>
            </div>
            <span className="font-bold text-[13px] text-on-surface">Calendrier</span>
            <span className="text-[11px] text-on-surface-variant leading-tight">Activités & Dates</span>
          </button>

          {/* C. Raccourci Progression */}
          <button
            onClick={onOpenProgression}
            className="bg-surface-container-lowest border border-outline-variant rounded-2xl p-3 flex flex-col items-center justify-center gap-1.5 shadow-xs hover:border-primary active:scale-95 transition-all cursor-pointer text-center"
          >
            <div className="w-11 h-11 rounded-full bg-primary-container flex items-center justify-center text-on-primary-container">
              <span className="material-symbols-outlined text-[26px]">donut_large</span>
            </div>
            <span className="font-bold text-[13px] text-on-surface">Progression</span>
            <span className="text-[11px] text-primary font-bold leading-tight">{progressPercent}% Terminé</span>
          </button>
        </section>

        {/* Conseil du Jour (Action mise en avant) */}
        <section className="bg-primary-container text-on-primary-container p-stack-md rounded-xl shadow-sm flex gap-stack-md items-start">
          <div className="bg-on-primary-container/20 p-2 rounded-lg shrink-0">
            <span className="material-symbols-outlined text-[32px]">water_drop</span>
          </div>
          <div className="flex-grow">
            <div className="flex items-center justify-between">
              <h3 className="text-[20px] leading-[28px] font-semibold mb-1">Conseil du jour</h3>
              {onReadAloud && (
                <button
                  onClick={() => onReadAloud(`Conseil du jour : ${adviceText}`)}
                  className="p-1 hover:bg-black/10 rounded-full active:scale-95 transition-all text-on-primary-container"
                  title="Écouter le conseil à haute voix"
                >
                  <span className="material-symbols-outlined text-[20px]">volume_up</span>
                </button>
              )}
            </div>
            <p className="text-[16px] leading-[24px] opacity-90">{adviceText}</p>
            <button
              onClick={() => setAdviceDone(!adviceDone)}
              className={`mt-stack-md px-stack-md py-2 rounded-full font-bold text-[14px] flex items-center gap-2 active:scale-95 transition-all cursor-pointer ${
                adviceDone
                  ? 'bg-secondary-container text-on-secondary-container'
                  : 'bg-surface-container-lowest text-primary'
              }`}
            >
              <span className="material-symbols-outlined text-[18px]">
                {adviceDone ? 'check_circle' : 'task_alt'}
              </span>
              {adviceDone ? 'Action marquée comme faite ✓' : 'Marquer comme fait'}
            </button>
          </div>
        </section>

        {/* Culture en cours & Prochaine étape */}
        <section className="bg-surface-container-lowest border border-outline-variant rounded-2xl overflow-hidden shadow-xs">
          <div className="h-40 w-full relative">
            <img src={activeCrop.image} alt={activeCrop.name} className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-4">
              <div className="text-white">
                <span className="text-[11px] font-bold uppercase tracking-wider bg-primary px-2.5 py-0.5 rounded-full inline-block mb-1">
                  Culture active
                </span>
                <h4 className="text-[20px] font-bold leading-tight">{activeCrop.name}</h4>
              </div>
            </div>
          </div>
          <div className="p-4 space-y-3">
            <div className="flex justify-between items-center text-sm">
              <span className="text-on-surface-variant">Progression dans le cycle :</span>
              <span className="font-bold text-primary">{progressPercent}% ({completedSteps}/{totalSteps} étapes)</span>
            </div>
            <div className="w-full h-2.5 bg-surface-container rounded-full overflow-hidden">
              <div className="h-full bg-primary rounded-full" style={{ width: `${progressPercent}%` }}></div>
            </div>
            <button
              onClick={onGoToActivities}
              className="w-full py-3 bg-primary text-on-primary rounded-xl font-bold text-[15px] flex items-center justify-center gap-2 active:scale-95 transition-transform shadow-xs cursor-pointer"
            >
              Accéder à mes activités de terrain
              <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
            </button>
          </div>
        </section>

        {/* Visual Context Card */}
        <div className="w-full h-44 rounded-xl overflow-hidden relative border border-outline-variant shadow-sm">
          <img
            alt={`Parcelle agricole à ${localityDisplay}`}
            className="w-full h-full object-cover"
            src={CROP_IMAGES.champGeneral}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-stack-md">
            <p className="text-white text-[14px] leading-[20px] font-semibold flex items-center gap-1">
              <span className="material-symbols-outlined text-sm">location_on</span>
              {localityDisplay}, Côte d'Ivoire
            </p>
          </div>
        </div>
      </main>

      {/* Modal Notifications */}
      {showNotificationModal && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-surface rounded-2xl p-6 max-w-sm w-full border border-outline-variant shadow-lg animate-fade-in">
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-[20px] font-bold text-primary flex items-center gap-2">
                <span className="material-symbols-outlined">notifications_active</span>
                Rappels agricoles
              </h4>
              <button
                onClick={() => setShowNotificationModal(false)}
                className="p-1 rounded-full hover:bg-surface-container cursor-pointer"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>
            <div className="space-y-3 text-sm">
              <div className="p-3 bg-secondary-container/40 rounded-lg border border-secondary/20">
                <p className="font-semibold text-secondary">Aujourd'hui - 16h00</p>
                <p className="text-on-surface">Surveiller l'arrosage avant le coucher du soleil.</p>
              </div>
              <div className="p-3 bg-surface-container-low rounded-lg border border-outline-variant">
                <p className="font-semibold text-primary">Demain matin</p>
                <p className="text-on-surface-variant">Contrôler l'apparition d'adventices sur la parcelle.</p>
              </div>
            </div>
            <button
              onClick={() => setShowNotificationModal(false)}
              className="mt-5 w-full py-2.5 bg-primary text-on-primary rounded-xl font-semibold active:scale-95 transition-transform cursor-pointer"
            >
              Compris
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
