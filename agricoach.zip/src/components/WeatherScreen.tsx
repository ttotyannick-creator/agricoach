/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { CROP_IMAGES } from '../data/agronomyData';
import { UserProfile } from '../types/agricoach';

interface WeatherScreenProps {
  userProfile: UserProfile;
  onBack: () => void;
  onReadAloud?: (text: string) => void;
}

export const WeatherScreen: React.FC<WeatherScreenProps> = ({
  userProfile,
  onBack,
  onReadAloud,
}) => {
  const [adviceDone, setAdviceDone] = useState(false);
  const localityDisplay = userProfile.locality || 'Yamoussoukro';

  const adviceText =
    "C'est le bon moment pour arroser vos plants. L'humidité du sol est basse et le soleil sera fort cet après-midi.";

  return (
    <div className="pb-32 max-w-md mx-auto">
      {/* Top Navigation Anchor */}
      <header className="bg-surface border-b border-outline-variant docked full-width top-0 flex justify-between items-center px-margin-mobile h-[56px] w-full sticky z-40 bg-opacity-95 backdrop-blur-sm">
        <div className="flex items-center gap-base">
          <button
            onClick={onBack}
            className="material-symbols-outlined text-primary cursor-pointer active:scale-95 transition-transform"
            title="Retour à l'accueil"
          >
            arrow_back
          </button>
          <div className="w-8 h-8 rounded-full overflow-hidden bg-secondary-container flex items-center justify-center border border-outline-variant">
            {CROP_IMAGES.farmerSmall ? (
              <img src={CROP_IMAGES.farmerSmall} alt="Avatar" className="w-full h-full object-cover" />
            ) : (
              <span className="material-symbols-outlined text-on-secondary-container fill-1 text-[20px]">
                account_circle
              </span>
            )}
          </div>
          <h1 className="text-[22px] leading-[28px] font-bold text-primary">Météo Agricole</h1>
        </div>
        {onReadAloud && (
          <button
            onClick={() =>
              onReadAloud(
                `Météo à ${localityDisplay} : 28 degrés, Ensoleillé. Humidité 65 pour cent, vent 12 kilomètres par heure. Conseil : ${adviceText}`
              )
            }
            className="active:scale-95 transition-transform hover:bg-surface-container-low p-2 rounded-full cursor-pointer text-primary"
            title="Écouter le bulletin météo"
          >
            <span className="material-symbols-outlined">volume_up</span>
          </button>
        )}
      </header>

      <main className="px-margin-mobile pt-stack-md flex flex-col gap-stack-lg">
        {/* Hero Weather Section */}
        <section className="weather-gradient rounded-xl p-stack-md border border-outline-variant shadow-sm relative overflow-hidden">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-[14px] leading-[20px] font-semibold text-on-surface-variant mb-1">
                Aujourd'hui à {localityDisplay}
              </p>
              <h2 className="text-[32px] leading-[40px] font-bold text-primary">28°C</h2>
              <p className="text-[20px] leading-[28px] font-semibold text-on-surface-variant">
                Ensoleillé
              </p>
            </div>
            <div className="flex flex-col items-end">
              <span className="material-symbols-outlined text-[80px] text-[#F9A825] fill-1">
                wb_sunny
              </span>
            </div>
          </div>

          {/* Detailed Stats Bento Grid */}
          <div className="grid grid-cols-2 gap-stack-sm mt-stack-md">
            <div className="bg-surface-container-lowest p-stack-md rounded-lg border border-outline-variant flex items-center gap-stack-sm">
              <span className="material-symbols-outlined text-primary text-[24px]">
                humidity_percentage
              </span>
              <div>
                <p className="text-[14px] leading-[20px] font-semibold text-on-surface-variant">
                  Humidité
                </p>
                <p className="text-[20px] leading-[28px] font-semibold text-on-surface">65%</p>
              </div>
            </div>
            <div className="bg-surface-container-lowest p-stack-md rounded-lg border border-outline-variant flex items-center gap-stack-sm">
              <span className="material-symbols-outlined text-primary text-[24px]">air</span>
              <div>
                <p className="text-[14px] leading-[20px] font-semibold text-on-surface-variant">
                  Vent
                </p>
                <p className="text-[20px] leading-[28px] font-semibold text-on-surface">12 km/h</p>
              </div>
            </div>
          </div>
        </section>

        {/* Conseil du Jour (Featured Action) */}
        <section className="bg-primary-container text-on-primary-container p-stack-md rounded-xl shadow-sm flex gap-stack-md items-start">
          <div className="bg-on-primary-container/20 p-2 rounded-lg shrink-0">
            <span className="material-symbols-outlined text-[32px]">water_drop</span>
          </div>
          <div className="flex-grow">
            <h3 className="text-[20px] leading-[28px] font-semibold mb-1">Conseil du jour</h3>
            <p className="text-[16px] leading-[24px] opacity-90">{adviceText}</p>
            <button
              onClick={() => setAdviceDone(!adviceDone)}
              className={`mt-stack-md px-stack-md py-2 rounded-full font-bold text-[14px] flex items-center gap-2 active:scale-95 transition-all cursor-pointer ${
                adviceDone
                  ? 'bg-secondary-container text-on-secondary-container'
                  : 'bg-surface-container-lowest text-primary'
              }`}
            >
              <span className="material-symbols-outlined text-[18px]">
                {adviceDone ? 'check_circle' : 'task_alt'}
              </span>
              {adviceDone ? 'Arrosage effectué ✓' : 'Marquer comme fait'}
            </button>
          </div>
        </section>

        {/* Prévisions de la semaine */}
        <section>
          <h3 className="text-[22px] leading-[28px] font-bold mb-stack-md text-on-surface">
            Prévisions de la semaine
          </h3>
          <div className="flex flex-col gap-base">
            <div className="flex items-center justify-between p-stack-md bg-surface border border-outline-variant rounded-lg">
              <p className="text-[20px] leading-[28px] font-semibold w-16 text-on-surface-variant">
                Mar
              </p>
              <div className="flex items-center gap-base">
                <span className="material-symbols-outlined text-primary fill-1">cloud</span>
                <p className="text-[16px] leading-[24px]">Nuageux</p>
              </div>
              <p className="text-[20px] leading-[28px] font-semibold text-primary">26° / 22°</p>
            </div>

            <div className="flex items-center justify-between p-stack-md bg-surface border border-outline-variant rounded-lg">
              <p className="text-[20px] leading-[28px] font-semibold w-16 text-on-surface-variant">
                Mer
              </p>
              <div className="flex items-center gap-base">
                <span className="material-symbols-outlined text-[#1976D2] fill-1">rainy</span>
                <p className="text-[16px] leading-[24px]">Pluie légère</p>
              </div>
              <p className="text-[20px] leading-[28px] font-semibold text-primary">24° / 21°</p>
            </div>

            <div className="flex items-center justify-between p-stack-md bg-surface border border-outline-variant rounded-lg">
              <p className="text-[20px] leading-[28px] font-semibold w-16 text-on-surface-variant">
                Jeu
              </p>
              <div className="flex items-center gap-base">
                <span className="material-symbols-outlined text-[#F9A825] fill-1">wb_sunny</span>
                <p className="text-[16px] leading-[24px]">Ensoleillé</p>
              </div>
              <p className="text-[20px] leading-[28px] font-semibold text-primary">30° / 23°</p>
            </div>
          </div>
        </section>

        {/* Visual Context Card */}
        <div className="w-full h-48 rounded-xl overflow-hidden relative border border-outline-variant shadow-sm">
          <img
            alt={`Champ de cacao à ${localityDisplay}`}
            className="w-full h-full object-cover"
            src={CROP_IMAGES.champGeneral}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-stack-md">
            <p className="text-white text-[14px] leading-[20px] font-semibold flex items-center gap-1">
              <span className="material-symbols-outlined text-sm">location_on</span>
              {localityDisplay}, Côte d'Ivoire
            </p>
          </div>
        </div>
      </main>
    </div>
  );
};
