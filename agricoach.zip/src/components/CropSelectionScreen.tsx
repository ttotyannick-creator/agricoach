/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { CROPS_DATA, CROP_IMAGES } from '../data/agronomyData';
import { Crop, CropCategory, UserProfile } from '../types/agricoach';

interface CropSelectionScreenProps {
  userProfile: UserProfile;
  onCropSelected: (cropId: string) => void;
  onReadAloud?: (text: string) => void;
}

export const CropSelectionScreen: React.FC<CropSelectionScreenProps> = ({
  userProfile,
  onCropSelected,
  onReadAloud,
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  const categoriesList: { name: CropCategory; icon: string }[] = [
    { name: 'Céréales', icon: 'grain' },
    { name: 'Tubercules', icon: 'restaurant' },
    { name: 'Légumineuses', icon: 'psychology_alt' },
    { name: 'Maraîchage', icon: 'yard' },
    { name: 'Autres', icon: 'category' },
  ];

  const handleSelect = (crop: Crop) => {
    if (onReadAloud) {
      onReadAloud(`Culture choisie : ${crop.name}. Initialisation de votre espace agricole à ${userProfile.locality}.`);
    }
    onCropSelected(crop.id);
  };

  const filteredCrops = CROPS_DATA.filter((c) =>
    c.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="bg-background text-on-surface min-h-screen pb-16 max-w-md mx-auto flex flex-col">
      {/* Top App Bar (Conforme à Image_15) */}
      <header className="bg-surface border-b border-outline-variant flex justify-between items-center px-margin-mobile h-[56px] w-full sticky top-0 z-40 bg-opacity-95 backdrop-blur-sm">
        <div className="flex items-center gap-base">
          <div className="w-8 h-8 rounded-full overflow-hidden bg-secondary-container flex items-center justify-center border border-outline-variant">
            {CROP_IMAGES.farmerSmall ? (
              <img src={CROP_IMAGES.farmerSmall} alt="Avatar" className="w-full h-full object-cover" />
            ) : (
              <span className="material-symbols-outlined text-on-secondary-container text-sm">
                person
              </span>
            )}
          </div>
          <h1 className="text-[22px] leading-[28px] font-bold text-primary">AgriCoach</h1>
        </div>
        <span className="material-symbols-outlined text-primary">notifications</span>
      </header>

      <main className="px-margin-mobile pt-stack-md flex-grow flex flex-col gap-5">
        {/* En-tête titre */}
        <div>
          <h2 className="text-[24px] leading-[32px] font-bold text-on-surface">
            Choisissez votre culture
          </h2>
          <p className="text-[16px] leading-[24px] text-on-surface-variant mt-1">
            Sélectionnez la culture que vous souhaitez planter pour obtenir des conseils personnalisés à{' '}
            <span className="font-bold text-primary">{userProfile.locality || 'votre région'}</span>.
          </p>
        </div>

        {/* Barre de recherche */}
        <div className="relative flex items-center">
          <span className="material-symbols-outlined absolute left-4 text-outline text-[20px]">
            search
          </span>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Rechercher une culture..."
            className="w-full h-[48px] pl-12 pr-4 bg-surface-container-lowest border border-outline-variant rounded-xl focus:border-primary focus:outline-none text-[16px] shadow-xs"
          />
        </div>

        {/* Grille par catégories (Image_15) */}
        {!searchQuery ? (
          <div className="space-y-6">
            {categoriesList.map((cat) => {
              const cropsInCat = CROPS_DATA.filter((c) => c.category === cat.name);
              if (cropsInCat.length === 0) return null;

              return (
                <section key={cat.name} className="space-y-3">
                  <div className="flex items-center gap-2">
                    <span className="material-symbols-outlined text-primary text-[22px]">
                      {cat.icon}
                    </span>
                    <h3 className="text-[20px] leading-[28px] font-bold text-on-surface">
                      {cat.name}
                    </h3>
                  </div>

                  <div className="grid grid-cols-2 gap-3.5">
                    {cropsInCat.map((crop) => (
                      <div
                        key={crop.id}
                        onClick={() => handleSelect(crop)}
                        className="bg-surface-container-lowest rounded-2xl overflow-hidden border border-outline-variant shadow-xs active:scale-95 transition-all cursor-pointer flex flex-col hover:border-primary"
                      >
                        <div className="h-32 w-full overflow-hidden bg-surface-container">
                          <img
                            src={crop.image}
                            alt={crop.name}
                            className="w-full h-full object-cover"
                            loading="lazy"
                          />
                        </div>
                        <div className="p-3 text-center flex-grow flex items-center justify-center">
                          <span className="font-bold text-[16px] text-on-surface">
                            {crop.name}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </section>
              );
            })}
          </div>
        ) : (
          /* Résultats de recherche filtrés */
          <div className="grid grid-cols-2 gap-3.5">
            {filteredCrops.map((crop) => (
              <div
                key={crop.id}
                onClick={() => handleSelect(crop)}
                className="bg-surface-container-lowest rounded-2xl overflow-hidden border border-outline-variant shadow-xs active:scale-95 transition-all cursor-pointer flex flex-col hover:border-primary"
              >
                <div className="h-32 w-full overflow-hidden bg-surface-container">
                  <img
                    src={crop.image}
                    alt={crop.name}
                    className="w-full h-full object-cover"
                    loading="lazy"
                  />
                </div>
                <div className="p-3 text-center flex-grow flex items-center justify-center">
                  <span className="font-bold text-[16px] text-on-surface">
                    {crop.name}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
};
