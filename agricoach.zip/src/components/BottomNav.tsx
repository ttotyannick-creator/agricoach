/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

export type NavTab = 'home' | 'crops' | 'activities' | 'profile';

interface BottomNavProps {
  currentTab: NavTab;
  onTabChange: (tab: NavTab) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ currentTab, onTabChange }) => {
  return (
    <nav className="fixed bottom-0 left-0 w-full z-50 flex justify-around items-center px-2 py-base bg-surface-container-lowest border-t border-outline-variant rounded-t-xl shadow-sm h-16 max-w-md left-1/2 -translate-x-1/2">
      {/* Onglet Accueil */}
      <button
        onClick={() => onTabChange('home')}
        className={`flex flex-col items-center justify-center p-2 rounded-lg transition-all duration-200 active:scale-90 cursor-pointer ${
          currentTab === 'home'
            ? 'text-primary border-b-4 border-primary pb-1'
            : 'text-on-surface-variant hover:bg-secondary-container'
        }`}
      >
        <span
          className={`material-symbols-outlined ${currentTab === 'home' ? 'fill-1' : ''}`}
          data-icon="home"
        >
          home
        </span>
        <span className="text-[14px] leading-[20px] font-semibold">Accueil</span>
      </button>

      {/* Onglet Cultures */}
      <button
        onClick={() => onTabChange('crops')}
        className={`flex flex-col items-center justify-center p-2 rounded-lg transition-all duration-200 active:scale-90 cursor-pointer ${
          currentTab === 'crops'
            ? 'text-primary border-b-4 border-primary pb-1'
            : 'text-on-surface-variant hover:bg-secondary-container'
        }`}
      >
        <span
          className={`material-symbols-outlined ${currentTab === 'crops' ? 'fill-1' : ''}`}
          data-icon="psychology_alt"
        >
          psychology_alt
        </span>
        <span className="text-[14px] leading-[20px] font-semibold">Cultures</span>
      </button>

      {/* Onglet Activités */}
      <button
        onClick={() => onTabChange('activities')}
        className={`flex flex-col items-center justify-center p-2 rounded-lg transition-all duration-200 active:scale-90 cursor-pointer ${
          currentTab === 'activities'
            ? 'text-primary border-b-4 border-primary pb-1'
            : 'text-on-surface-variant hover:bg-secondary-container'
        }`}
      >
        <span
          className={`material-symbols-outlined ${currentTab === 'activities' ? 'fill-1' : ''}`}
          data-icon="event_note"
        >
          event_note
        </span>
        <span className="text-[14px] leading-[20px] font-semibold">Activités</span>
      </button>

      {/* Onglet Profil */}
      <button
        onClick={() => onTabChange('profile')}
        className={`flex flex-col items-center justify-center p-2 rounded-lg transition-all duration-200 active:scale-90 cursor-pointer ${
          currentTab === 'profile'
            ? 'text-primary border-b-4 border-primary pb-1'
            : 'text-on-surface-variant hover:bg-secondary-container'
        }`}
      >
        <span
          className={`material-symbols-outlined ${currentTab === 'profile' ? 'fill-1' : ''}`}
          data-icon="person"
        >
          person
        </span>
        <span className="text-[14px] leading-[20px] font-semibold">Profil</span>
      </button>
    </nav>
  );
};
