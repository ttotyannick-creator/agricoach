/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { CROP_IMAGES, getCropByIdWithProgress } from '../data/agronomyData';
import { UserProfile } from '../types/agricoach';

interface CalendarScreenProps {
  userProfile: UserProfile;
  onBack: () => void;
  onReadAloud?: (text: string) => void;
}

export const CalendarScreen: React.FC<CalendarScreenProps> = ({
  userProfile,
  onBack,
  onReadAloud,
}) => {
  const [selectedDay, setSelectedDay] = useState<number>(11);
  const [todayTaskCompleted, setTodayTaskCompleted] = useState<boolean>(false);
  const [showAddTaskModal, setShowAddTaskModal] = useState<boolean>(false);
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskZone, setNewTaskZone] = useState('');

  const activeCrop = getCropByIdWithProgress(userProfile.cropSelectedId, userProfile);

  const [upcomingTasks, setUpcomingTasks] = useState([
    {
      id: 1,
      month: 'OCT',
      day: 12,
      title: 'Fertilisation de fond',
      subtitle: `Apport de compost organique - Parcelle ${activeCrop.name}`,
    },
    {
      id: 2,
      month: 'OCT',
      day: 14,
      title: 'Désherbage manuel',
      subtitle: 'Nettoyage des adventices à la daba - Zone 1',
    },
    {
      id: 3,
      month: 'OCT',
      day: 18,
      title: `Surveillance de la levée`,
      subtitle: `Contrôle des jeunes plants de ${activeCrop.name}`,
    },
  ]);

  const daysOfWeek = ['Lu', 'Ma', 'Me', 'Je', 'Ve', 'Sa', 'Di'];
  const calendarDays = [
    { day: 25, isCurrentMonth: false },
    { day: 26, isCurrentMonth: false },
    { day: 27, isCurrentMonth: false },
    { day: 28, isCurrentMonth: false },
    { day: 29, isCurrentMonth: false },
    { day: 30, isCurrentMonth: false },
    { day: 1, isCurrentMonth: true },
    { day: 2, isCurrentMonth: true },
    { day: 3, isCurrentMonth: true },
    { day: 4, isCurrentMonth: true },
    { day: 5, isCurrentMonth: true },
    { day: 6, isCurrentMonth: true },
    { day: 7, isCurrentMonth: true },
    { day: 8, isCurrentMonth: true },
    { day: 9, isCurrentMonth: true },
    { day: 10, isCurrentMonth: true },
    { day: 11, isCurrentMonth: true },
    { day: 12, isCurrentMonth: true },
    { day: 13, isCurrentMonth: true },
    { day: 14, isCurrentMonth: true },
    { day: 15, isCurrentMonth: true },
    { day: 16, isCurrentMonth: true },
    { day: 17, isCurrentMonth: true },
    { day: 18, isCurrentMonth: true },
    { day: 19, isCurrentMonth: true },
    { day: 20, isCurrentMonth: true },
    { day: 21, isCurrentMonth: true },
    { day: 22, isCurrentMonth: true },
    { day: 23, isCurrentMonth: true },
    { day: 24, isCurrentMonth: true },
    { day: 25, isCurrentMonth: true },
    { day: 26, isCurrentMonth: true },
    { day: 27, isCurrentMonth: true },
    { day: 28, isCurrentMonth: true },
    { day: 29, isCurrentMonth: true },
    { day: 30, isCurrentMonth: true },
    { day: 31, isCurrentMonth: true },
  ];

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (newTaskTitle.trim()) {
      setUpcomingTasks([
        ...upcomingTasks,
        {
          id: Date.now(),
          month: 'OCT',
          day: selectedDay,
          title: newTaskTitle.trim(),
          subtitle: newTaskZone.trim() || `Parcelle ${userProfile.locality}`,
        },
      ]);
      setNewTaskTitle('');
      setNewTaskZone('');
      setShowAddTaskModal(false);
      if (onReadAloud) {
        onReadAloud(`Activité ${newTaskTitle} ajoutée à votre calendrier pour le ${selectedDay} octobre.`);
      }
    }
  };

  return (
    <div className="pb-32 max-w-md mx-auto">
      {/* Top App Bar */}
      <header className="bg-surface border-b border-outline-variant flex justify-between items-center px-margin-mobile h-[56px] w-full sticky top-0 z-40 bg-opacity-95 backdrop-blur-sm">
        <div className="flex items-center gap-base">
          <button
            onClick={onBack}
            className="material-symbols-outlined text-primary cursor-pointer active:scale-95 transition-transform mr-1"
            title="Retour à l'accueil"
          >
            arrow_back
          </button>
          <div className="w-8 h-8 rounded-full bg-secondary-container flex items-center justify-center overflow-hidden border border-outline-variant">
            {CROP_IMAGES.farmerSmall ? (
              <img src={CROP_IMAGES.farmerSmall} alt="Avatar" className="w-full h-full object-cover" />
            ) : (
              <span className="material-symbols-outlined text-on-secondary-container text-[20px]">
                person
              </span>
            )}
          </div>
          <h1 className="text-[22px] leading-[28px] font-bold text-primary">AgriCoach</h1>
        </div>
        <button className="material-symbols-outlined text-primary active:scale-95 transition-transform p-1">
          notifications
        </button>
      </header>

      <main className="px-margin-mobile pt-stack-md flex flex-col gap-5">
        {/* Header Title */}
        <div>
          <div className="flex items-center justify-between">
            <h2 className="text-[24px] leading-[32px] font-bold text-on-surface">Calendrier Agricole</h2>
            {onReadAloud && (
              <button
                onClick={() =>
                  onReadAloud(
                    `Calendrier d'octobre. Aujourd'hui : Semis du ${activeCrop.name}, Parcelle Nord, prévu entre 8h et 12h.`
                  )
                }
                className="text-primary hover:bg-primary/10 p-1.5 rounded-full"
                title="Écouter le calendrier"
              >
                <span className="material-symbols-outlined text-[20px]">volume_up</span>
              </button>
            )}
          </div>
          <p className="text-[16px] leading-[24px] text-on-surface-variant">
            Planifiez vos cultures et suivez vos progrès.
          </p>
        </div>

        {/* Calendar Card (Exactement comme Image_9) */}
        <section className="bg-surface-container-lowest border border-outline-variant rounded-2xl p-4 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-[18px] text-on-surface">Octobre 2023</h3>
            <div className="flex items-center gap-2">
              <button className="p-1 text-on-surface hover:bg-surface-container rounded-full">
                <span className="material-symbols-outlined text-[20px]">chevron_left</span>
              </button>
              <button className="p-1 text-on-surface hover:bg-surface-container rounded-full">
                <span className="material-symbols-outlined text-[20px]">chevron_right</span>
              </button>
            </div>
          </div>

          {/* Days Header */}
          <div className="grid grid-cols-7 text-center mb-2">
            {daysOfWeek.map((day) => (
              <span key={day} className="text-[13px] font-semibold text-on-surface-variant">
                {day}
              </span>
            ))}
          </div>

          {/* Days Grid */}
          <div className="grid grid-cols-7 gap-y-2 text-center text-[15px]">
            {calendarDays.map((item, idx) => {
              const isSelected = item.isCurrentMonth && item.day === selectedDay;
              return (
                <button
                  key={idx}
                  onClick={() => {
                    if (item.isCurrentMonth) setSelectedDay(item.day);
                  }}
                  className={`h-9 w-9 mx-auto flex items-center justify-center rounded-full transition-all cursor-pointer ${
                    !item.isCurrentMonth
                      ? 'text-outline/40 cursor-default'
                      : isSelected
                      ? 'bg-primary text-on-primary font-bold shadow-xs'
                      : 'text-on-surface hover:bg-surface-container-low font-medium'
                  }`}
                >
                  {item.day}
                </button>
              );
            })}
          </div>
        </section>

        {/* Section Aujourd'hui */}
        <section className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-primary text-[22px]">event</span>
            <h3 className="font-bold text-[18px] text-on-surface">Aujourd'hui</h3>
          </div>

          <div className="bg-primary text-on-primary rounded-2xl p-4 flex items-center justify-between shadow-sm">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-primary shrink-0">
                <span className="material-symbols-outlined text-[28px]">potted_plant</span>
              </div>
              <div>
                <h4 className="font-bold text-[17px] leading-tight">
                  Semis du {activeCrop.name}
                </h4>
                <p className="text-[13px] text-on-primary/90 mt-0.5">
                  Parcelle Nord • 08:00 - 12:00
                </p>
              </div>
            </div>

            <button
              onClick={() => {
                setTodayTaskCompleted(!todayTaskCompleted);
                if (onReadAloud) {
                  onReadAloud(
                    todayTaskCompleted
                      ? 'Tâche remise en attente'
                      : `Félicitations ! Semis du ${activeCrop.name} marqué comme terminé.`
                  );
                }
              }}
              className={`w-10 h-10 rounded-full flex items-center justify-center border-2 border-white/60 transition-all cursor-pointer ${
                todayTaskCompleted ? 'bg-white text-primary' : 'hover:bg-white/20'
              }`}
              title="Valider la tâche du jour"
            >
              <span className="material-symbols-outlined text-[22px] font-bold">check</span>
            </button>
          </div>
        </section>

        {/* Section À venir */}
        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-secondary text-[22px]">
                calendar_month
              </span>
              <h3 className="font-bold text-[18px] text-on-surface">À venir</h3>
            </div>
            <button
              onClick={() => setShowAddTaskModal(true)}
              className="text-xs font-bold text-primary hover:underline cursor-pointer"
            >
              Voir tout
            </button>
          </div>

          <div className="space-y-2.5">
            {upcomingTasks.map((task) => (
              <div
                key={task.id}
                className="bg-surface-container-lowest border border-outline-variant rounded-2xl p-3.5 flex items-center justify-between shadow-xs"
              >
                <div className="flex items-center gap-4">
                  <div className="text-center w-12 border-r border-outline-variant/60 pr-3">
                    <span className="text-[11px] font-bold text-on-surface-variant uppercase block">
                      {task.month}
                    </span>
                    <span className="text-[20px] font-bold text-on-surface leading-tight">
                      {task.day}
                    </span>
                  </div>
                  <div>
                    <h5 className="font-bold text-[15px] text-on-surface">{task.title}</h5>
                    <p className="text-[13px] text-on-surface-variant">{task.subtitle}</p>
                  </div>
                </div>
                <button className="text-outline hover:text-on-surface p-1">
                  <span className="material-symbols-outlined text-[20px]">more_vert</span>
                </button>
              </div>
            ))}
          </div>
        </section>
      </main>

      {/* Bouton Flottant (+) pour ajouter une activité au calendrier */}
      <div className="fixed bottom-20 right-6 z-40 max-w-md">
        <button
          onClick={() => setShowAddTaskModal(true)}
          className="w-14 h-14 bg-primary text-on-primary rounded-2xl flex items-center justify-center shadow-lg active:scale-90 transition-transform cursor-pointer"
          title="Planifier une nouvelle activité"
        >
          <span className="material-symbols-outlined text-3xl">add</span>
        </button>
      </div>

      {/* Modal Ajout d'activité */}
      {showAddTaskModal && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-surface rounded-2xl p-6 max-w-sm w-full border border-outline-variant shadow-2xl space-y-4 animate-fade-in">
            <div className="flex items-center justify-between border-b pb-3 border-outline-variant">
              <h4 className="font-bold text-lg text-primary flex items-center gap-2">
                <span className="material-symbols-outlined">edit_calendar</span>
                Planifier une activité
              </h4>
              <button
                onClick={() => setShowAddTaskModal(false)}
                className="p-1 rounded-full hover:bg-surface-container"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <form onSubmit={handleAddTask} className="space-y-3">
              <div>
                <label className="text-xs font-bold text-on-surface-variant block mb-1">
                  Nom de l'opération
                </label>
                <input
                  type="text"
                  value={newTaskTitle}
                  onChange={(e) => setNewTaskTitle(e.target.value)}
                  placeholder="Ex: Deuxième désherbage"
                  className="w-full px-3 py-2 bg-surface-container-lowest border border-outline-variant rounded-xl text-sm focus:border-primary focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-bold text-on-surface-variant block mb-1">
                  Parcelle ou zone
                </label>
                <input
                  type="text"
                  value={newTaskZone}
                  onChange={(e) => setNewTaskZone(e.target.value)}
                  placeholder="Ex: Parcelle Sud - 09:00"
                  className="w-full px-3 py-2 bg-surface-container-lowest border border-outline-variant rounded-xl text-sm focus:border-primary focus:outline-none"
                />
              </div>

              <div className="text-xs text-on-surface-variant">
                Date sélectionnée : <span className="font-bold text-primary">{selectedDay} Octobre 2023</span>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddTaskModal(false)}
                  className="w-1/2 py-2.5 bg-surface-container rounded-xl font-semibold text-sm"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="w-1/2 py-2.5 bg-primary text-on-primary rounded-xl font-bold text-sm shadow-sm active:scale-95"
                >
                  Ajouter
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
