/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useState } from 'react';
import { CROP_IMAGES, getCropByIdWithProgress } from '../data/agronomyData';
import { ProductionStep, UserProfile } from '../types/agricoach';

interface ActivitiesScreenProps {
  userProfile: UserProfile;
  selectedCropId: string;
  initialStepIndex?: number;
  onValidateStep?: (
    cropId: string,
    stepId: number,
    data: { completedDate: string; photoProof?: string }
  ) => void;
  onBackToCycle: () => void;
  onReadAloud?: (text: string) => void;
}

export const ActivitiesScreen: React.FC<ActivitiesScreenProps> = ({
  userProfile,
  selectedCropId,
  initialStepIndex = 0,
  onValidateStep,
  onBackToCycle,
  onReadAloud,
}) => {
  const crop = getCropByIdWithProgress(selectedCropId, userProfile);
  const steps = crop.steps;

  // Trouver la première étape non complétée ou l'étape demandée
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(() => {
    if (initialStepIndex >= 0 && initialStepIndex < steps.length) {
      return initialStepIndex;
    }
    const firstUncompleted = steps.findIndex((s) => !s.completed);
    return firstUncompleted >= 0 ? firstUncompleted : 0;
  });

  const currentStep = steps[currentStepIndex] || steps[0];
  const totalSteps = steps.length || 6;
  const completedCount = steps.filter((s) => s.completed).length;
  const progressPercent = Math.round((completedCount / totalSteps) * 100);

  // État du parcours pédagogique obligatoire :
  // 'idle' -> 'watching_video' -> 'qcm' -> 'photo' -> 'validated'
  const [learningStage, setLearningStage] = useState<'idle' | 'video' | 'qcm' | 'photo' | 'validated'>('idle');

  // État du QCM de 3 questions
  const [qcmQuestionIndex, setQcmQuestionIndex] = useState<number>(0);
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([]);
  const [qcmCompleted, setQcmCompleted] = useState<boolean>(false);
  const [qcmScore, setQcmScore] = useState<number>(0);

  // État de la prise de photo
  const [attachedPhoto, setAttachedPhoto] = useState<string | null>(currentStep.photoProof || null);
  const [isSubmittingValidation, setIsSubmittingValidation] = useState<boolean>(false);
  const [showProblemModal, setShowProblemModal] = useState<boolean>(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // 1. Déclenchement de la vidéo
  const handleStartVideo = () => {
    setLearningStage('video');
    if (onReadAloud) {
      onReadAloud(`Lancement de la vidéo explicative : ${currentStep.videoTitle || currentStep.title}`);
    }
  };

  // 2. Fin de la vidéo -> bascule automatique sur le QCM de 3 questions
  const handleVideoFinished = () => {
    setLearningStage('qcm');
    setQcmQuestionIndex(0);
    setSelectedAnswers([]);
    setQcmCompleted(false);
    if (onReadAloud) {
      onReadAloud(
        `Vidéo terminée. Voici le questionnaire de validation en 3 questions pour tester votre compréhension.`
      );
    }
  };

  // 3. Réponse à une question du QCM
  const questionsList = currentStep.quizQuestions && currentStep.quizQuestions.length === 3
    ? currentStep.quizQuestions
    : [
        {
          question: `À quelle profondeur minimale faut-il travailler pour le ${crop.name} ?`,
          options: ['5 cm', '20 cm', '50 cm'],
          correctIndex: 1,
          explanation: 'Un labour à 20 cm assure un volume meuble suffisant pour les racines.',
        },
        {
          question: 'Quel est le rôle du compost organique ?',
          options: ['Retenir l’eau et nourrir la terre', 'Remplacer le soleil', 'Tuer les vers utiles'],
          correctIndex: 0,
          explanation: 'Le compost enrichit le sol en matière organique et retient l’humidité de pluie.',
        },
        {
          question: 'Quand faut-il désherber la parcelle ?',
          options: ['Dès 15 jours après la levée', 'Après la récolte', 'Une fois par an'],
          correctIndex: 0,
          explanation: 'Un sarclage précoce empêche les adventices de voler l’engrais aux jeunes plants.',
        },
      ];

  const currentQuestion = questionsList[qcmQuestionIndex];

  const handleSelectAnswer = (optionIdx: number) => {
    const updatedAnswers = [...selectedAnswers];
    updatedAnswers[qcmQuestionIndex] = optionIdx;
    setSelectedAnswers(updatedAnswers);

    const isCorrect = optionIdx === currentQuestion.correctIndex;
    if (onReadAloud) {
      if (isCorrect) {
        onReadAloud(`Exact ! ${currentQuestion.explanation}`);
      } else {
        onReadAloud(`Attention. La bonne réponse est : ${currentQuestion.options[currentQuestion.correctIndex]}. ${currentQuestion.explanation}`);
      }
    }

    // Passer à la question suivante après 1.8 seconde
    setTimeout(() => {
      if (qcmQuestionIndex < questionsList.length - 1) {
        setQcmQuestionIndex((prev) => prev + 1);
      } else {
        // Calcul du score final sur les 3 questions
        let score = 0;
        questionsList.forEach((q, idx) => {
          if (updatedAnswers[idx] === q.correctIndex) {
            score += 1;
          }
        });
        setQcmScore(score);
        setQcmCompleted(true);
      }
    }, 1800);
  };

  // 4. Passage à la prise de photo après le QCM réussi
  const handleProceedToPhoto = () => {
    setLearningStage('photo');
    if (onReadAloud) {
      onReadAloud(
        `Félicitations pour le questionnaire ! Veuillez maintenant prendre une photo de votre travail agricole sur la parcelle pour valider l'activité.`
      );
    }
  };

  // 5. Prise de photo
  const handlePhotoCapture = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const photoData = event.target?.result as string;
        setAttachedPhoto(photoData);
        currentStep.photoProof = photoData;
        if (onReadAloud) {
          onReadAloud(`Photo capturée avec succès. Vous pouvez maintenant soumettre l'étape pour validation.`);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // 6. Validation finale et déblocage de l'étape suivante
  const handleSubmitValidation = () => {
    const photoToSubmit = attachedPhoto || currentStep.image || crop.image;
    if (!attachedPhoto) {
      setAttachedPhoto(photoToSubmit);
      currentStep.photoProof = photoToSubmit;
    }

    setIsSubmittingValidation(true);

    setTimeout(() => {
      const validationDate = new Date().toLocaleDateString('fr-FR', {
        day: 'numeric',
        month: 'long',
        year: 'numeric',
      });
      currentStep.completed = true;
      currentStep.validationStatus = 'valide';
      currentStep.completedDate = validationDate;

      // Persistance automatique dans le profil utilisateur et localStorage
      if (onValidateStep) {
        onValidateStep(selectedCropId, currentStep.id, {
          completedDate: validationDate,
          photoProof: photoToSubmit,
        });
      }

      setIsSubmittingValidation(false);
      setLearningStage('validated');

      if (onReadAloud) {
        onReadAloud(
          `Bravo ${userProfile.name} ! L'étape « ${currentStep.title} » a été validée avec succès. L'activité suivante est débloquée.`
        );
      }
    }, 1000);
  };

  // Passer à l'activité suivante débloquée
  const handleGoToNextStep = () => {
    if (currentStepIndex < steps.length - 1) {
      setCurrentStepIndex((prev) => prev + 1);
      setLearningStage('idle');
      setAttachedPhoto(null);
      setQcmCompleted(false);
      setSelectedAnswers([]);
      setQcmQuestionIndex(0);
    } else {
      onBackToCycle();
    }
  };

  return (
    <div className="pb-32 max-w-md mx-auto">
      {/* Top App Bar */}
      <header className="bg-surface border-b border-outline-variant flex justify-between items-center px-margin-mobile h-[56px] w-full sticky top-0 z-40 bg-opacity-95 backdrop-blur-sm">
        <div className="flex items-center gap-base">
          <button
            onClick={onBackToCycle}
            className="material-symbols-outlined text-primary cursor-pointer active:scale-95 transition-transform"
            data-icon="arrow_back"
          >
            arrow_back
          </button>
          <h1 className="text-[22px] leading-[28px] font-bold text-primary">
            {crop.name} : Activités
          </h1>
        </div>
        <div className="flex items-center gap-margin-mobile">
          <span className="material-symbols-outlined text-primary cursor-pointer">
            notifications
          </span>
          <div className="w-8 h-8 rounded-full bg-secondary-container flex items-center justify-center border border-outline overflow-hidden">
            {CROP_IMAGES.farmerSmall ? (
              <img src={CROP_IMAGES.farmerSmall} alt="Avatar" className="w-full h-full object-cover" />
            ) : (
              <span className="material-symbols-outlined text-on-secondary-container text-sm">
                person
              </span>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-screen-md mx-auto px-margin-mobile pt-stack-md flex flex-col gap-stack-lg">
        {/* Progress Overview (2 / 6 étapes) */}
        <section className="flex flex-col gap-stack-sm">
          <div className="flex justify-between items-end">
            <h2 className="text-[20px] leading-[28px] font-semibold text-on-surface">
              Étape {currentStep.stepNumber} : {currentStep.title.split(' ')[0]}
            </h2>
            <span className="text-[14px] leading-[20px] font-semibold text-primary">
              {completedCount} / {totalSteps} validées ({progressPercent}%)
            </span>
          </div>
          <div className="w-full h-3 bg-surface-container rounded-full overflow-hidden">
            <div
              className="h-full bg-primary rounded-full transition-all duration-500"
              style={{ width: `${progressPercent}%` }}
            ></div>
          </div>
        </section>

        {/* Message de validation réussie */}
        {learningStage === 'validated' && (
          <div className="p-4 bg-primary text-on-primary rounded-2xl flex flex-col gap-3 shadow-sm animate-fade-in">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-2xl fill-1">check_circle</span>
              <h4 className="font-bold text-base">Étape {currentStep.stepNumber} validée avec succès !</h4>
            </div>
            <p className="text-xs text-on-primary/90">
              La vidéo a été visionnée, les 3 questions du QCM ont été validées et la photo de votre parcelle est enregistrée.
            </p>
            {currentStepIndex < steps.length - 1 ? (
              <button
                onClick={handleGoToNextStep}
                className="w-full py-2.5 bg-white text-primary rounded-xl font-bold text-sm shadow-sm active:scale-95 transition-transform cursor-pointer"
              >
                Débloquer et passer à l'étape suivante →
              </button>
            ) : (
              <button
                onClick={onBackToCycle}
                className="w-full py-2.5 bg-white text-primary rounded-xl font-bold text-sm shadow-sm active:scale-95 transition-transform cursor-pointer"
              >
                Voir le bilan complet de progression
              </button>
            )}
          </div>
        )}

        {/* ============================================================== */}
        {/* PARCOURS EN 6 POINTS OBLIGATOIRES                             */}
        {/* ============================================================== */}

        {/* 1. Carte principale d'étape avec bouton VIDÉO (Image_6) */}
        {learningStage === 'idle' && (
          <article className="bg-surface-container-lowest border border-outline-variant rounded-xl overflow-hidden shadow-sm">
            <div className="relative h-48 w-full overflow-hidden bg-surface-container">
              <img
                alt={currentStep.title}
                className="w-full h-full object-cover"
                src={currentStep.image || crop.image}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-gutter">
                <span className="bg-primary text-on-primary px-3 py-1 rounded-full text-[14px] font-semibold uppercase tracking-wider">
                  {currentStep.completed ? 'Validé' : 'Actif'}
                </span>
              </div>
            </div>

            <div className="p-gutter flex flex-col gap-stack-md">
              <div>
                <div className="flex items-center justify-between">
                  <h3 className="text-[24px] leading-[32px] font-bold mb-1 text-on-surface">
                    {currentStep.title}
                  </h3>
                  {onReadAloud && (
                    <button
                      onClick={() =>
                        onReadAloud(
                          `${currentStep.title}. ${currentStep.shortDescription} Comment : ${currentStep.detailedGuidance.how} Quand : ${currentStep.detailedGuidance.when} Pourquoi : ${currentStep.detailedGuidance.why}`
                        )
                      }
                      className="p-1 text-primary hover:bg-primary/10 rounded-full"
                      title="Lire les consignes de l'étape"
                    >
                      <span className="material-symbols-outlined text-[20px]">volume_up</span>
                    </button>
                  )}
                </div>
                <p className="text-[16px] leading-[24px] text-on-surface-variant">
                  {currentStep.shortDescription}
                </p>
              </div>

              {/* Détails agronomiques concrets */}
              <div className="bg-surface-container-low p-3.5 rounded-xl border border-outline-variant space-y-2 text-xs">
                <div>
                  <span className="font-bold text-primary">Comment faire : </span>
                  <span className="text-on-surface-variant">{currentStep.detailedGuidance.how}</span>
                </div>
                <div>
                  <span className="font-bold text-secondary">Quand le faire : </span>
                  <span className="text-on-surface-variant">{currentStep.detailedGuidance.when}</span>
                </div>
                <div>
                  <span className="font-bold text-tertiary">Pourquoi : </span>
                  <span className="text-on-surface-variant">{currentStep.detailedGuidance.why}</span>
                </div>
              </div>

              {/* PREMIÈREMENT : Bouton Regarder la vidéo */}
              <button
                onClick={handleStartVideo}
                className="flex items-center justify-center gap-base bg-secondary-container text-on-secondary-container h-[56px] rounded-lg w-full font-bold text-[18px] active:scale-95 transition-transform cursor-pointer shadow-xs"
              >
                <span className="material-symbols-outlined" data-icon="play_circle">
                  play_circle
                </span>
                Regarder la vidéo
              </button>
            </div>
          </article>
        )}

        {/* 1. LECTEUR VIDÉO EXPLICATIVE EN COURS */}
        {learningStage === 'video' && (
          <section className="bg-surface-container-lowest border border-outline-variant rounded-2xl overflow-hidden shadow-md p-4 space-y-4 animate-fade-in">
            <div className="flex items-center justify-between border-b pb-2">
              <h3 className="font-bold text-primary flex items-center gap-2">
                <span className="material-symbols-outlined">play_circle</span>
                Vidéo explicative : Étape {currentStep.stepNumber}
              </h3>
              <span className="text-xs text-on-surface-variant">{currentStep.videoDuration || '3 min 30s'}</span>
            </div>

            <div className="aspect-video bg-black rounded-xl overflow-hidden relative flex flex-col items-center justify-center text-white">
              <img
                src={currentStep.image || crop.image}
                alt="Miniature vidéo"
                className="w-full h-full object-cover opacity-60"
              />
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/40 p-4 text-center">
                <div className="w-16 h-16 bg-primary text-white rounded-full flex items-center justify-center shadow-lg active:scale-95 cursor-pointer mb-2 animate-pulse">
                  <span className="material-symbols-outlined text-4xl">play_arrow</span>
                </div>
                <p className="font-bold text-sm text-white drop-shadow">
                  {currentStep.videoTitle}
                </p>
                <span className="text-xs text-white/80 mt-1">
                  Démonstration pratique sur parcelle en Côte d'Ivoire
                </span>
              </div>
            </div>

            <div className="p-3 bg-surface-container-low rounded-xl text-xs text-on-surface-variant space-y-1">
              <p className="font-bold text-on-surface">À observer attentivement dans la vidéo :</p>
              <ul className="list-disc pl-4 space-y-0.5">
                <li>Le geste technique et l'angle d'utilisation de la daba</li>
                <li>Le dosage de l'amendement organique et son enfouissement</li>
                <li>Les signes d'humidité idéale de la terre</li>
              </ul>
            </div>

            {/* DEUXIÈMEMENT : Bouton fin de vidéo menant au QCM */}
            <button
              onClick={handleVideoFinished}
              className="w-full h-[52px] bg-primary text-on-primary rounded-xl font-bold text-base flex items-center justify-center gap-2 active:scale-95 shadow-sm cursor-pointer"
            >
              Vidéo terminée : Passer au QCM de validation
              <span className="material-symbols-outlined">arrow_forward</span>
            </button>
          </section>
        )}

        {/* 2 & 3. QCM DE 3 QUESTIONS AVEC CORRECTION & EXPLICATIONS */}
        {learningStage === 'qcm' && (
          <section className="bg-tertiary-fixed text-on-tertiary-fixed p-gutter rounded-xl border border-outline-variant shadow-sm animate-fade-in">
            <div className="flex items-center justify-between mb-stack-sm">
              <div className="flex items-center gap-base">
                <span className="material-symbols-outlined" data-icon="quiz">
                  quiz
                </span>
                <h4 className="text-[20px] leading-[28px] font-semibold">
                  QCM de validation ({qcmQuestionIndex + 1} / {questionsList.length})
                </h4>
              </div>
              <span className="text-xs font-bold bg-white/40 px-2.5 py-0.5 rounded-full">
                Question {qcmQuestionIndex + 1}
              </span>
            </div>

            {!qcmCompleted ? (
              <div>
                <p className="text-[16px] leading-[24px] font-medium mb-stack-md">
                  {currentQuestion.question}
                </p>
                <div className="flex flex-col gap-base">
                  {currentQuestion.options.map((option, idx) => {
                    const isSelected = selectedAnswers[qcmQuestionIndex] === idx;
                    const hasAnswered = selectedAnswers[qcmQuestionIndex] !== undefined;
                    const isCorrect = idx === currentQuestion.correctIndex;

                    let btnStyle = 'bg-surface-container-lowest border-outline text-on-surface';
                    if (hasAnswered) {
                      if (isCorrect) {
                        btnStyle = 'bg-primary-container text-on-primary-container border-primary font-bold';
                      } else if (isSelected) {
                        btnStyle = 'bg-error-container text-on-error-container border-error';
                      }
                    }

                    return (
                      <button
                        key={idx}
                        disabled={hasAnswered}
                        onClick={() => handleSelectAnswer(idx)}
                        className={`flex items-center justify-between p-base border rounded-lg transition-colors text-left cursor-pointer active:scale-[0.99] ${btnStyle}`}
                      >
                        <span className="text-[16px] leading-[24px]">{option}</span>
                        <span
                          className={`material-symbols-outlined text-[20px] ${
                            hasAnswered && isCorrect ? 'opacity-100 text-on-primary-container' : 'opacity-0'
                          }`}
                        >
                          check
                        </span>
                      </button>
                    );
                  })}
                </div>

                {selectedAnswers[qcmQuestionIndex] !== undefined && (
                  <div className="mt-3 p-3 bg-surface-container-lowest/90 rounded-lg text-xs text-on-surface border border-outline-variant animate-fade-in">
                    <p className="font-semibold text-primary mb-0.5">Explication agronomique :</p>
                    <p>{currentQuestion.explanation}</p>
                  </div>
                )}
              </div>
            ) : (
              /* Résultat du QCM */
              <div className="space-y-4 py-2">
                <div className="text-center bg-white/70 rounded-xl p-4 border border-outline-variant">
                  <span className="material-symbols-outlined text-4xl text-primary fill-1 mb-1">
                    workspace_premium
                  </span>
                  <h5 className="font-bold text-lg text-primary">
                    Résultat du questionnaire : {qcmScore} / {questionsList.length}
                  </h5>
                  <p className="text-xs text-on-surface mt-1">
                    {qcmScore >= 2
                      ? 'Excellente maîtrise des consignes agricoles pour cette étape !'
                      : 'Bravo d’avoir suivi les explications. Vous pouvez maintenant passer à la pratique.'}
                  </p>
                </div>

                {/* QUATRIÈMEMENT : Passer à la prise de photo */}
                <button
                  onClick={handleProceedToPhoto}
                  className="w-full h-[52px] bg-primary text-on-primary rounded-xl font-bold text-base flex items-center justify-center gap-2 active:scale-95 shadow-sm cursor-pointer"
                >
                  Prendre la photo de mon travail sur la parcelle
                  <span className="material-symbols-outlined">photo_camera</span>
                </button>
              </div>
            )}
          </section>
        )}

        {/* 4 & 5. PRISE DE PHOTO & SOUMISSION À VALIDATION */}
        {learningStage === 'photo' && (
          <section className="bg-surface-container-lowest border border-outline-variant rounded-2xl p-5 shadow-sm space-y-4 animate-fade-in">
            <div className="flex items-center gap-2 border-b pb-2">
              <span className="material-symbols-outlined text-primary text-2xl">photo_camera</span>
              <h3 className="font-bold text-lg text-on-surface">
                Preuve photo de votre travail agricole
              </h3>
            </div>

            <p className="text-sm text-on-surface-variant leading-relaxed">
              Pour valider définitivement l'étape « {currentStep.title} », prenez une photo de votre parcelle ou de votre travail réalisé (sol labouré, poquets réguliers, etc.).
            </p>

            <input
              type="file"
              ref={fileInputRef}
              accept="image/*"
              className="hidden"
              onChange={handlePhotoCapture}
            />

            <div
              onClick={() => fileInputRef.current?.click()}
              className="h-44 w-full rounded-2xl border-2 border-dashed border-primary/50 bg-primary/5 flex flex-col items-center justify-center text-center p-4 cursor-pointer hover:bg-primary/10 transition-colors relative overflow-hidden"
            >
              {attachedPhoto ? (
                <>
                  <img src={attachedPhoto} alt="Preuve photo" className="absolute inset-0 w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/40 flex flex-col items-center justify-center text-white p-2">
                    <span className="material-symbols-outlined text-3xl fill-1">check_circle</span>
                    <span className="font-bold text-sm mt-1">Photo enregistrée</span>
                    <span className="text-xs underline mt-1">Appuyer pour changer</span>
                  </div>
                </>
              ) : (
                <>
                  <div className="w-14 h-14 bg-primary text-white rounded-full flex items-center justify-center mb-2 shadow-sm">
                    <span className="material-symbols-outlined text-3xl">photo_camera</span>
                  </div>
                  <span className="font-bold text-sm text-primary">Prendre une photo de la parcelle</span>
                  <span className="text-xs text-on-surface-variant mt-1">Ou choisir depuis la galerie</span>
                </>
              )}
            </div>

            {/* CINQUIÈMEMENT & SIXIÈMEMENT : Soumettre l'activité à validation */}
            <button
              onClick={handleSubmitValidation}
              disabled={isSubmittingValidation}
              className="w-full h-[54px] bg-primary text-on-primary rounded-xl font-bold text-base flex items-center justify-center gap-2 active:scale-95 shadow-sm transition-transform cursor-pointer"
            >
              {isSubmittingValidation ? (
                <span className="flex items-center gap-2">
                  <span className="material-symbols-outlined animate-spin">progress_activity</span>
                  Validation en cours...
                </span>
              ) : (
                <>
                  <span className="material-symbols-outlined fill-1">task_alt</span>
                  Soumettre l'activité à validation
                </>
              )}
            </button>
          </section>
        )}

        {/* Boutons d'action contextuels (Image_6) */}
        {learningStage === 'idle' && (
          <section className="grid grid-cols-1 gap-stack-md">
            {/* Bouton J'ai réalisé direct */}
            <button
              onClick={handleStartVideo}
              className="flex items-center justify-between px-gutter bg-primary text-on-primary h-[56px] rounded-lg font-bold text-[18px] active:scale-95 transition-transform shadow-sm cursor-pointer"
            >
              <div className="flex items-center gap-base">
                <span className="material-symbols-outlined fill-1" data-icon="check_circle">
                  check_circle
                </span>
                J'ai réalisé
              </div>
              <span className="material-symbols-outlined" data-icon="chevron_right">
                chevron_right
              </span>
            </button>

            {/* Grille Prendre une photo / J'ai un problème */}
            <div className="grid grid-cols-2 gap-stack-md">
              <button
                onClick={() => {
                  setLearningStage('photo');
                  setTimeout(() => fileInputRef.current?.click(), 100);
                }}
                className="flex flex-col items-center justify-center gap-base bg-surface-container-lowest border border-outline h-24 rounded-lg text-on-surface-variant font-semibold text-[14px] active:scale-95 transition-transform cursor-pointer"
              >
                <span className="material-symbols-outlined text-primary text-3xl" data-icon="photo_camera">
                  photo_camera
                </span>
                Prendre une photo
              </button>

              <button
                onClick={() => setShowProblemModal(true)}
                className="flex flex-col items-center justify-center gap-base bg-surface-container-lowest border border-error h-24 rounded-lg text-error font-semibold text-[14px] active:scale-95 transition-transform cursor-pointer"
              >
                <span className="material-symbols-outlined text-3xl" data-icon="report_problem">
                  report_problem
                </span>
                J'ai un problème
              </button>
            </div>
          </section>
        )}

        {/* Modal J'ai un problème sur ma parcelle */}
        {showProblemModal && (
          <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
            <div className="bg-surface rounded-2xl max-w-md w-full p-6 shadow-2xl border border-outline-variant space-y-4 animate-fade-in">
              <div className="flex items-center justify-between border-b border-outline-variant pb-3">
                <h4 className="font-bold text-lg text-error flex items-center gap-2">
                  <span className="material-symbols-outlined">report_problem</span>
                  Signaler un problème
                </h4>
                <button
                  onClick={() => setShowProblemModal(false)}
                  className="p-1 rounded-full hover:bg-surface-container cursor-pointer"
                >
                  <span className="material-symbols-outlined">close</span>
                </button>
              </div>

              <p className="text-sm text-on-surface-variant">
                Quel problème observez-vous sur votre parcelle de {crop.name} à {userProfile.locality} ?
              </p>

              <div className="space-y-2 text-sm">
                <button
                  onClick={() => {
                    const msg = `Pour un sol trop durci à ${userProfile.locality}, attendez une pluie de 15 mm ou arrosez légèrement le soir avant de labourer pour ne pas casser votre outil.`;
                    if (onReadAloud) onReadAloud(msg);
                    setShowProblemModal(false);
                  }}
                  className="w-full text-left p-3 rounded-xl bg-surface-container-low border border-outline-variant hover:border-primary font-semibold cursor-pointer active:scale-[0.99]"
                >
                  🪨 Le sol est trop dur ou caillouteux
                </button>

                <button
                  onClick={() => {
                    const msg = `Des feuilles jaunissantes indiquent souvent une asphyxie racinaire après de fortes pluies ou un manque d'azote. Vérifiez le drainage de la parcelle.`;
                    if (onReadAloud) onReadAloud(msg);
                    setShowProblemModal(false);
                  }}
                  className="w-full text-left p-3 rounded-xl bg-surface-container-low border border-outline-variant hover:border-primary font-semibold cursor-pointer active:scale-[0.99]"
                >
                  🍂 Feuilles jaunes ou flétries
                </button>

                <button
                  onClick={() => {
                    const msg = `Contre les chenilles légionnaires du maïs en Côte d'Ivoire, inspectez le cornet et appliquez une préparation naturelle au neem tôt le matin.`;
                    if (onReadAloud) onReadAloud(msg);
                    setShowProblemModal(false);
                  }}
                  className="w-full text-left p-3 rounded-xl bg-surface-container-low border border-outline-variant hover:border-primary font-semibold cursor-pointer active:scale-[0.99]"
                >
                  🐛 Présence d'insectes ou de chenilles
                </button>
              </div>

              <button
                onClick={() => setShowProblemModal(false)}
                className="w-full py-2.5 bg-surface-container text-on-surface rounded-xl font-semibold text-sm cursor-pointer"
              >
                Fermer
              </button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};
