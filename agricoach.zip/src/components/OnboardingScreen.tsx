/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { UserProfile } from '../types/agricoach';

interface OnboardingScreenProps {
  onComplete: (profile: { name: string; locality: string }) => void;
  initialProfile?: UserProfile;
}

export const OnboardingScreen: React.FC<OnboardingScreenProps> = ({ onComplete, initialProfile }) => {
  const [name, setName] = useState(initialProfile?.name || '');
  const [locality, setLocality] = useState(initialProfile?.locality || '');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setErrorMessage('Veuillez renseigner votre nom.');
      return;
    }
    if (!locality.trim()) {
      setErrorMessage('Veuillez renseigner votre localité.');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      onComplete({
        name: name.trim(),
        locality: locality.trim(),
      });
      setIsLoading(false);
    }, 600);
  };

  return (
    <div className="bg-background text-on-surface min-h-screen flex flex-col items-center">
      <div className="w-full max-w-md mx-auto flex flex-col min-h-screen">
        {/* En-tête avec image de champ ivoirien */}
        <div className="w-full h-[353px] relative overflow-hidden">
          <img
            alt="Champ de cacao ivoirien au lever du soleil"
            className="w-full h-full object-cover"
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuB0vvZxYyUzAwLAIkLBxF3VdGLtvanwMNQ_m-MDD2h2ezByZ497rudmpLwDTypn-JgtAIJffSGcDvYCCauwibe7GpI7ktoUqVA-mGnJGs51gTSPY2-JVZvuHJ31MVxCK1ec1RkPGy5tuATsBDtcApp4q-DvRh9Uo6ZbS59GJU261Iy0hk1ynSwhb54cnkvm2X04DULM7EH60-caSquokA8NXtKkKTWcjLKY7iC6NZW-7dXBP_AU-EH5uLFcTjsWGoJFJUbZMxw68Hs"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent"></div>
        </div>

        {/* Formulaire principal dans le conteneur arrondi */}
        <main className="flex-grow px-margin-mobile -mt-10 relative z-10 bg-background rounded-t-[32px] flex flex-col pt-stack-lg shadow-sm">
          <header className="mb-stack-lg text-center">
            <h1 className="text-[22px] leading-[28px] font-bold text-primary mb-2">Bienvenue sur AgriCoach</h1>
            <p className="text-[16px] leading-[24px] text-on-surface-variant">Votre conseiller agricole digital pour une récolte abondante.</p>
          </header>

          <form className="flex flex-col space-y-stack-md" onSubmit={handleSubmit}>
            {errorMessage && (
              <div className="p-3 bg-error-container text-on-error-container rounded-lg text-sm">
                {errorMessage}
              </div>
            )}

            <div className="flex flex-col">
              <label className="text-label-lg font-semibold text-on-surface-variant mb-2 ml-1" htmlFor="name">
                Nom
              </label>
              <div className="relative flex items-center">
                <span className="material-symbols-outlined absolute left-4 text-outline" data-icon="person">
                  person
                </span>
                <input
                  id="name"
                  type="text"
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);
                    if (errorMessage) setErrorMessage('');
                  }}
                  placeholder="Ex: Jean Kouassi"
                  className="w-full h-[56px] pl-12 pr-4 bg-surface-container-lowest border-2 border-outline-variant rounded-xl focus:border-primary focus:outline-none transition-colors text-body-md"
                />
              </div>
            </div>

            <div className="flex flex-col">
              <label className="text-label-lg font-semibold text-on-surface-variant mb-2 ml-1" htmlFor="location">
                Localité
              </label>
              <div className="relative flex items-center">
                <span className="material-symbols-outlined absolute left-4 text-outline" data-icon="location_on">
                  location_on
                </span>
                <input
                  id="location"
                  type="text"
                  value={locality}
                  onChange={(e) => {
                    setLocality(e.target.value);
                    if (errorMessage) setErrorMessage('');
                  }}
                  placeholder="Ex: Yamoussoukro"
                  className="w-full h-[56px] pl-12 pr-4 bg-surface-container-lowest border-2 border-outline-variant rounded-xl focus:border-primary focus:outline-none transition-colors text-body-md"
                />
              </div>
            </div>

            <div className="pt-stack-lg">
              <button
                type="submit"
                disabled={isLoading}
                className="w-full h-[56px] bg-primary text-on-primary rounded-xl font-bold text-[18px] flex items-center justify-center gap-base active:scale-[0.98] transition-transform shadow-sm cursor-pointer disabled:opacity-75"
              >
                {isLoading ? (
                  <span className="flex items-center gap-2">
                    <span className="material-symbols-outlined animate-spin">progress_activity</span>
                    Initialisation...
                  </span>
                ) : (
                  <>
                    Commencer
                    <span className="material-symbols-outlined" data-icon="arrow_forward">
                      arrow_forward
                    </span>
                  </>
                )}
              </button>
            </div>
          </form>

          <footer className="mt-auto py-stack-lg text-center">
            <p className="text-[14px] text-outline">
              En continuant, vous acceptez nos <span className="text-primary font-bold cursor-pointer">Conditions d'utilisation</span>
            </p>
          </footer>
        </main>
      </div>
    </div>
  );
};
