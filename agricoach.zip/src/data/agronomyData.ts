/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Crop, LocalityAdaptation, ProductionStep, StepProgressData, UserProfile } from '../types/agricoach';

// Images réalistes extraites directement des maquettes authentiques du projet
export const CROP_IMAGES = {
  riz: '/assets/crops/riz_large.png',
  rizThumb: '/assets/crops/riz.png',
  mais: '/assets/crops/mais_large.png',
  maisThumb: '/assets/crops/mais.png',
  manioc: '/assets/crops/manioc_large.png',
  maniocThumb: '/assets/crops/manioc.png',
  igname: '/assets/crops/igname.png',
  patate_douce: '/assets/crops/patate_douce.png',
  taro: '/assets/crops/taro.png',
  arachide: '/assets/crops/arachide.png',
  haricot: '/assets/crops/haricot.png',
  tomate: '/assets/crops/tomate.png',
  piment: '/assets/crops/piment.png',
  gombo: '/assets/crops/gombo.png',
  oignon: '/assets/crops/oignon.png',
  banane: '/assets/crops/banane_large.png',
  bananeThumb: '/assets/crops/banane_plantain.png',
  champGeneral: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCaidwkObPGAyjGS6PMo_-_WJt2lNPZ6ovMxOfauLZJR03tMCKVSpUGSvgyj_DwgJGrj4YgcTvkmYT5d4Mvlx43HTJXBKA30kx73dOA4217LhWxCbH8edztjN6Yp5ujIAkMwZtoNy7g4hg3HPgzwTHNA8L7Sq7MQtX1Czr0jisWYtmBVT9a8x7gNr-BuP76hHFNTDd_8xKjanfHjvLTMkCIiIIZtxaCQFIXqCU2QpHQR8nptOIo4b6UdGitbpZ_iGbpTECd2bK7Ruw',
  farmerAvatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDwuV324a8JM-06pScs348hSacYf1oqvanWvzlPb8CNahuaSwqqWDrrosbGjn_vDEgoTaKgVphpbl_VV94E4A0xN6MmxkrC5dl-evTm8JbW_g0zq6zjuJEErw1tq3O9Eq7v2HKd54h9cmun9ciJeQFS_u5QTgugje4atO3P0Y37Yg3a1O-EZFLWuiXgyd62mnjTgfGJVR-9SMC5GcI22e33zrxN_4ZpdvQL5nVPEEt3Izav-aH4tIIkalDPsPCarMkMLKAIy5AUtbs',
  farmerSmall: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAhZw3fjpYhWAO-_8YniK7ySGOr14y79Hf-eTo0QOa61UrtMi-FxCV6GToAhF92-Y3tm8A981C33PYBmdgPQ8Rc29oU3znpYBWYedulh3u1T0yrvB5m7Lrz42Df_r9s8TWtR1qy2gII-65Imy-GTSmD2BdI1Y9OKH3f-b56oJz7BlyTcIs2hi_4AnHi8GsV-gT0It_oBsc40RdVbOQ5WAYirJ2Rdtc6HPX5YtvUxY0nwBNBvRfUIMAtqvA1TkASqDv32jgASQPm83M',
};

// Fonction génératrice de 6 étapes agronomiques pour une culture
function createStepsForCrop(cropName: string, imageSrc: string): ProductionStep[] {
  return [
    {
      id: 1,
      stepNumber: 1,
      title: 'Préparation et diagnostic du sol',
      shortDescription: `Ameublir la parcelle sur 20 cm pour favoriser un enracinement robuste de votre culture de ${cropName}.`,
      detailedGuidance: {
        what: `Nettoyer le terrain, évacuer les débris ligneux et labourer la terre sans remonter les couches profondes stériles.`,
        how: `Utiliser la daba pour décompacter les mottes et briser les croûtes de battance.`,
        when: `Deux à trois semaines avant la plantation, dès les premières pluies utiles.`,
        why: `Un sol meuble permet aux jeunes racines de ${cropName} d'absorber l'eau et de respirer sans asphyxie.`
      },
      durationText: '1 à 2 semaines',
      badgeText: 'Actif',
      image: imageSrc,
      videoTitle: `Guide pratique : Préparation et diagnostic optimal du sol pour ${cropName}`,
      videoDuration: '3 min 30s',
      completed: false,
      validationStatus: 'non_commence',
      quizQuestions: [
        {
          question: `À quelle profondeur minimale faut-il labourer le sol pour le ${cropName} ?`,
          options: ['5 cm', '20 cm', '50 cm'],
          correctIndex: 1,
          explanation: 'Un labour à 20 cm offre un volume exploré suffisant par les racines tout en protégeant la matière organique de surface.'
        },
        {
          question: 'Quel est l’état idéal de la terre avant le travail du sol ?',
          options: ['Complètement inondée', 'Légèrement humide et meuble (ressuyée)', 'Totalement desséchée et poussiéreuse'],
          correctIndex: 1,
          explanation: 'Un sol bien ressuyé permet un travail facile sans former de blocs compacts ni écraser la structure du sol.'
        },
        {
          question: 'Pourquoi ne faut-il pas retourner les couches profondes stériles ?',
          options: ['Pour préserver la couche fertile en surface', 'Pour fatiguer moins la daba', 'Pour laisser passer le vent'],
          correctIndex: 0,
          explanation: 'La vie microbienne et l’humus se concentrent dans les 15 premiers centimètres ; les enterrer étouffe le sol.'
        }
      ]
    },
    {
      id: 2,
      stepNumber: 2,
      title: 'Restauration et fertilisation du sol',
      shortDescription: `Apportez du compost mûr ou de la matière organique pour restaurer la fertilité durable de la parcelle.`,
      detailedGuidance: {
        what: 'Épandre le compost bien décomposé ou la fumure de fond à raison de 5 à 10 tonnes par hectare.',
        how: 'Enfouir légèrement lors du dernier hersage ou localiser dans les poquets.',
        when: 'Quelques jours avant le semis ou repiquage.',
        why: 'Restaure l’humus, retient l’humidité de pluie et active les micro-organismes bénéfiques.'
      },
      durationText: '3 à 5 jours',
      image: imageSrc,
      videoTitle: `Compostage et restauration de la fertilité du sol pour ${cropName}`,
      videoDuration: '4 min 10s',
      completed: false,
      validationStatus: 'non_commence',
      quizQuestions: [
        {
          question: 'Quel est le rôle essentiel de la matière organique dans le sol ?',
          options: ['Remplacer la lumière du soleil', 'Retenir l’eau et nourrir durablement la plante', 'Éliminer tous les insectes'],
          correctIndex: 1,
          explanation: 'Le compost agit comme une éponge qui retient l’humidité et libère progressivement les minéraux.'
        },
        {
          question: 'Comment reconnaître un compost bien mûr et sans danger ?',
          options: ['Il dégage une odeur de terre forestière et a une couleur sombre', 'Il fume et sent mauvais', 'Il est plein de morceaux verts frais'],
          correctIndex: 0,
          explanation: 'Un compost mûr est noir, homogène et sent le sous-bois frais ; il ne brûle pas les racines.'
        },
        {
          question: 'Pourquoi privilégier les pratiques durables comme le paillage ?',
          options: ['Pour éviter d’acheter de la peinture', 'Pour limiter l’évaporation et protéger le sol du soleil ardent', 'Pour attirer les oiseaux'],
          correctIndex: 1,
          explanation: 'Le paillage protège la terre du dessèchement et enrichit le sol en se dégradant naturellement.'
        }
      ]
    },
    {
      id: 3,
      stepNumber: 3,
      title: 'Préparation des semences et plantation',
      shortDescription: 'Sélectionnez des semences saines et respectez scrupuleusement les densités de plantation.',
      detailedGuidance: {
        what: `Trier les semences saines, traiter si nécessaire et planter selon les écartements agronomiques.`,
        how: 'Creuser les poquets en lignes régulières, déposer les graines ou boutures et recouvrir de terre fine.',
        when: 'Au début de la matinée ou en fin d’après-midi sur un sol bien humide après une bonne pluie.',
        why: 'Un bon écartement évite l’étouffement mutuel des plants et maximise le rendement par hectare.'
      },
      durationText: '1 à 2 jours',
      badgeText: 'Actif',
      image: imageSrc,
      videoTitle: `Techniques de tri des semences et plantation optimale de ${cropName}`,
      videoDuration: '3 min 45s',
      completed: false,
      validationStatus: 'non_commence',
      quizQuestions: [
        {
          question: `À quelle profondeur doit-on placer la semence ou le plant de ${cropName} ?`,
          options: ['1 cm en surface', '3 à 5 cm selon la taille de la graine', '25 cm au fond du trou'],
          correctIndex: 1,
          explanation: 'Une profondeur de 3 à 5 cm assure l’humidité nécessaire sans épuiser les réserves de la jeune pousse.'
        },
        {
          question: 'Pourquoi semer en lignes régulières plutôt qu’à la volée ?',
          options: ['Pour que le champ soit plus joli', 'Pour faciliter le désherbage et garantir la densité idéale', 'Pour économiser les arrosoirs'],
          correctIndex: 1,
          explanation: 'Les lignes facilitent les passages d’entretien à la daba et évitent la surpopulation des plants.'
        },
        {
          question: 'Quel test simple permet de vérifier la germination des graines avant le semis ?',
          options: ['Le test de flottaison dans l’eau ou sur chiffon humide', 'Goûter les graines crues', 'Les peser sur une balance'],
          correctIndex: 0,
          explanation: 'Faire germer 20 graines sur un linge humide permet de mesurer le taux de germination avant de semer la parcelle.'
        }
      ]
    },
    {
      id: 4,
      stepNumber: 4,
      title: 'Entretien de la culture et gestion de l’eau',
      shortDescription: 'Désherbez manuellement, régulez l’arrosage et paillez pour préserver la fraîcheur du sol.',
      detailedGuidance: {
        what: `Sarcler entre les lignes pour supprimer les mauvaises herbes et gérer l’irrigation en cas de poche de sécheresse.`,
        how: 'À la daba en coupant les adventices au ras du sol sans entamer les racines utiles.',
        when: '15 à 20 jours après la levée, dès l’apparition des premières herbes concurrentes.',
        why: 'Les mauvaises herbes consomment jusqu’à 50% de l’eau et des nutriments destinés à la plante.'
      },
      durationText: '2 à 3 jours',
      image: imageSrc,
      videoTitle: `Désherbage précoce, paillage et gestion de l’eau pour ${cropName}`,
      videoDuration: '4 min 00s',
      completed: false,
      validationStatus: 'non_commence',
      quizQuestions: [
        {
          question: 'À quel moment de la journée est-il préférable d’arroser votre culture ?',
          options: ['En plein midi sous le soleil chaud', 'Tôt le matin ou en fin d’après-midi', 'Uniquement à minuit'],
          correctIndex: 1,
          explanation: 'Arroser aux heures fraîches évite l’évaporation immédiate et les brûlures foliaires causées par l’effet loupe.'
        },
        {
          question: 'Pourquoi le premier sarclage doit-il être fait très tôt ?',
          options: ['Pour empêcher les herbes de voler l’engrais et l’eau', 'Pour faire sécher la daba', 'Pour vendre les herbes arrachées'],
          correctIndex: 0,
          explanation: 'La concurrence au stade juvénile pénalise irréversiblement la formation future des récoltes.'
        },
        {
          question: 'Quel est l’intérêt du buttage lors de l’entretien ?',
          options: ['Renforcer l’ancrage des racines et protéger les tiges', 'Bloquer le passage de l’air', 'Attirer les criquets'],
          correctIndex: 0,
          explanation: 'Ramener de la terre au pied des plants soutient les tiges contre le vent et favorise de nouvelles racines adventives.'
        }
      ]
    },
    {
      id: 5,
      stepNumber: 5,
      title: 'Protection et suivi du développement de la plante',
      shortDescription: 'Surveillez l’apparition des maladies et ravageurs, et apportez la fertilisation complémentaire.',
      detailedGuidance: {
        what: 'Inspecter régulièrement les feuilles, tiges et fleurs, et apporter l’engrais de soutien (urée ou potasse).',
        how: 'Enfouir l’engrais à 5-10 cm du pied et appliquer des biopesticides naturels (neem) en cas d’attaque.',
        when: 'Au stade de forte élongation et au début de la floraison.',
        why: 'Protège la production avant que les attaques d’insectes ou les carences ne diminuent le rendement.'
      },
      durationText: '1 à 2 semaines',
      image: imageSrc,
      videoTitle: `Surveillance phytosanitaire et fertilisation d’appoint pour ${cropName}`,
      videoDuration: '4 min 20s',
      completed: false,
      validationStatus: 'non_commence',
      quizQuestions: [
        {
          question: 'Que faut-il faire en observant les premiers trous de chenilles dans les feuilles ?',
          options: ['Attendre la fin de la récolte', 'Intervenir immédiatement (ramassage manuel ou bio-solution neem)', 'Inonder le champ d’eau salée'],
          correctIndex: 1,
          explanation: 'Une intervention dès les premières larves évite la prolifération fulgurante des ravageurs comme la légionnaire.'
        },
        {
          question: 'Où doit être déposée la fertilisation complémentaire ?',
          options: ['Directement sur les feuilles', 'Enfouie à 5-10 cm du pied sans toucher la tige', 'À 2 mètres du champ'],
          correctIndex: 1,
          explanation: 'L’engrais doit être au contact de la terre humide près des racines pour ne pas brûler les tissus végétaux.'
        },
        {
          question: 'Quel signe indique une carence en azote sur la plante ?',
          options: ['Les feuilles inférieures jaunissent en forme de V', 'Les racines deviennent violettes', 'Les tiges deviennent dures comme du bois'],
          correctIndex: 0,
          explanation: 'Le jaunissement des vieilles feuilles du bas signale un manque urgent d’azote que la plante tente de compenser.'
        }
      ]
    },
    {
      id: 6,
      stepNumber: 6,
      title: 'Récolte et bilan de production',
      shortDescription: 'Récoltez au bon stade de maturité, faites sécher correctement et évaluez vos rendements.',
      detailedGuidance: {
        what: `Cueillir ou arracher les produits à maturité optimale et les stocker dans des conditions aérées et sèches.`,
        how: 'Manipuler avec soin pour éviter les meurtrissures, faire sécher sur claies et ensacher dans des sacs propres.',
        when: 'Par temps sec et ensoleillé, dès que les indices de maturité sont atteints.',
        why: 'Un séchage rigoureux élimine le risque d’aflatoxines et garantit la meilleure valeur marchande.'
      },
      durationText: '1 à 2 semaines',
      image: imageSrc,
      videoTitle: `Techniques de récolte, séchage et stockage sécurisé pour ${cropName}`,
      videoDuration: '4 min 50s',
      completed: false,
      validationStatus: 'non_commence',
      quizQuestions: [
        {
          question: 'Quelle est la condition météo indispensable le jour de la récolte ?',
          options: ['Une pluie battante', 'Un temps sec et ensoleillé', 'Un ciel d’orage très humide'],
          correctIndex: 1,
          explanation: 'Récolter par temps sec limite l’humidité résiduelle qui favorise les moisissures pendant le stockage.'
        },
        {
          question: 'Pourquoi est-il crucial de faire sécher les récoltes sur des bâches ou claies surélevées ?',
          options: ['Pour éviter le contact avec le sol humide et les souillures', 'Pour chauffer les grains au feu', 'Pour les cacher aux voisins'],
          correctIndex: 0,
          explanation: 'Les claies surélevées permettent à l’air de circuler dessous et empêchent l’humidité du sol de pourrir la récolte.'
        },
        {
          question: 'Pourquoi faire un bilan de production en fin de récolte ?',
          options: ['Pour mesurer sa rentabilité et améliorer la prochaine saison', 'Pour payer plus d’impôts', 'Pour jeter les semences'],
          correctIndex: 0,
          explanation: 'Le bilan permet d’identifier ce qui a bien marché et les points d’amélioration pour la campagne suivante.'
        }
      ]
    }
  ];
}

// Données agronomiques de toutes les cultures ivoiriennes
export const CROPS_DATA: Crop[] = [
  // 1. CÉRÉALES
  {
    id: 'riz',
    name: 'Riz',
    category: 'Céréales',
    duration: '4-5 mois',
    description: 'Culture vivrière essentielle, base de nombreux repas quotidiens.',
    image: CROP_IMAGES.riz,
    isPrincipal: true,
    steps: createStepsForCrop('Riz', CROP_IMAGES.riz),
    defaultAdaptation: {
      level: 'ADAPTEE',
      levelLabel: 'Très bien adaptée (Bas-fonds & Pluvial)',
      reasons: 'Le riz pluvial ou irrigué de bas-fond est particulièrement performant dans les vallées de Côte d’Ivoire riches en alluvions et humidité.',
      climateAndSoil: 'Sols hydromorphes, limoneux à argileux retenant l’eau. Forte humidité et pluviométrie > 1 200 mm.',
      pros: ['Très forte demande de consommation en Côte d’Ivoire', 'Excellents rendements en bas-fond aménagé'],
      cons: ['Sensible à la pyriculariose en cas d’excès d’azote', 'Gestion de l’enherbement exigeante en main-d’œuvre'],
      bestPractices: 'Bien niveler le casier de bas-fond et repiquer à 20x20 cm en lignes.',
      soilAdvice: 'Apporter de la paille de riz compostée pour recycler le potassium.'
    },
    adaptationByLocality: {
      yamoussoukro: {
        level: 'ADAPTEE',
        levelLabel: 'Adaptée en bas-fonds aménagés',
        reasons: 'Nombreux bas-fonds propices autour du lac et dans la région des Lacs.',
        climateAndSoil: 'Pluviométrie bimodale favorable.',
        pros: ['Disponibilité d’eau pour irrigation', 'Proximité des unités d’usinage'],
        cons: ['Compétition pour la main d’œuvre agricole'],
        bestPractices: 'Contrôler les niveaux d’eau par diguettes.',
        soilAdvice: 'Fumure équilibrée NPK 12-24-18.'
      }
    }
  },
  {
    id: 'mais',
    name: 'Maïs',
    category: 'Céréales',
    duration: '3-4 mois',
    description: 'Croissance rapide, nécessite un bon apport en eau.',
    image: CROP_IMAGES.mais,
    isPrincipal: false,
    steps: createStepsForCrop('Maïs', CROP_IMAGES.mais),
    defaultAdaptation: {
      level: 'ADAPTEE',
      levelLabel: 'Très bien adaptée',
      reasons: 'Le maïs est une céréale vivrière majeure en Côte d’Ivoire, capable de produire sur la majorité des terroirs si les pluies dépassent 800 mm.',
      climateAndSoil: 'Température optimale de 25 à 32°C. Sols meubles, profonds et riches en azote et phosphore.',
      pros: ['Cycle court (3 à 4 mois) fournissant une récolte rapide', 'Consommation familiale et vente aisée sur tous les marchés'],
      cons: ['Très exigeant en eau pendant la phase de floraison', 'Sensible aux chenilles légionnaires'],
      bestPractices: 'Ameublir le sol sur 20 cm, semer à 3-5 cm de profondeur et butter au stade genou.',
      soilAdvice: 'Apport de fumier ou compost au labour, puis NPK au semis et urée au stade 8 feuilles.'
    },
    adaptationByLocality: {
      soubre: {
        level: 'MOYENNE',
        levelLabel: 'Moyennement adaptée',
        reasons: 'Zone très humide, risque de moisissure des épis lors de la récolte en saison des pluies.',
        climateAndSoil: 'Sols forestiers très riches mais humides.',
        pros: ['Croissance foliaire rapide'],
        cons: ['Séchage difficile des grains', 'Pression fongique accrue'],
        bestPractices: 'Semer tôt en mars pour récolter en juillet avant les fortes pluies.',
        soilAdvice: 'Drainer les parcelles en pente douce.'
      },
      yamoussoukro: {
        level: 'ADAPTEE',
        levelLabel: 'Parfaitement adaptée',
        reasons: 'Climat bimodal idéal permettant 2 récoltes par an dans le V-Baoulé.',
        climateAndSoil: 'Sols ferrallitiques remaniés de texture moyenne.',
        pros: ['Deux cycles possibles par an', 'Marché très actif'],
        cons: ['Sécheresse passagère possible en août'],
        bestPractices: 'Semer dès l’installation franche des pluies en avril.',
        soilAdvice: 'Apport régulier de matière organique.'
      }
    }
  },

  // 2. TUBERCULES
  {
    id: 'manioc',
    name: 'Manioc',
    category: 'Tubercules',
    duration: '12 mois',
    description: 'Base de l’alimentation, résistant et facile à cultiver.',
    image: CROP_IMAGES.manioc,
    isPrincipal: false,
    steps: createStepsForCrop('Manioc', CROP_IMAGES.manioc),
    defaultAdaptation: {
      level: 'ADAPTEE',
      levelLabel: 'Culture très rustique et adaptée',
      reasons: 'Le manioc supporte de courtes périodes de sécheresse et pousse sur presque tous les sols ivoiriens sans engrais lourds.',
      climateAndSoil: 'Sols meubles et aérés permettant le bon grossissement des tubercules.',
      pros: ['Très résistant aux aléas climatiques', 'Transformation lucrative en attiéké et gari'],
      cons: ['Cycle plus long (9 à 12 mois)', 'Sensible à la mosaïque africaine du manioc'],
      bestPractices: 'Utiliser des boutures saines de 25 cm plantées obliquement.',
      soilAdvice: 'Pratiquer des billons ou de petites buttes pour faciliter le développement des racines.'
    },
    adaptationByLocality: {}
  },
  {
    id: 'igname',
    name: 'Igname',
    category: 'Tubercules',
    duration: '7-9 mois',
    description: 'Culture vivrière de prestige, tubercules très prisés pour le foutou.',
    image: CROP_IMAGES.igname,
    isPrincipal: false,
    steps: createStepsForCrop('Igname', CROP_IMAGES.igname),
    defaultAdaptation: {
      level: 'ADAPTEE',
      levelLabel: 'Excellente en zone Centre et Est',
      reasons: 'Culture emblématique du V-Baoulé, du Gontougo (Bondoukou) et du Bounkani.',
      climateAndSoil: 'Sols sablo-argileux profonds, légers et riches en humus.',
      pros: ['Très forte valeur commerciale', 'Consommation culturelle incontournable'],
      cons: ['Exige un travail important de buttage et tuteurage'],
      bestPractices: 'Confectionner des buttes volumineuses de 60 à 80 cm bien aérées.',
      soilAdvice: 'Pailler le sommet de la butte après la mise en terre du semenceau.'
    },
    adaptationByLocality: {}
  },
  {
    id: 'patate_douce',
    name: 'Patate douce',
    category: 'Tubercules',
    duration: '3-4 mois',
    description: 'Tubercule à cycle court, riche en énergie et vitamines.',
    image: CROP_IMAGES.patate_douce,
    isPrincipal: false,
    steps: createStepsForCrop('Patate douce', CROP_IMAGES.patate_douce),
    defaultAdaptation: {
      level: 'ADAPTEE',
      levelLabel: 'Très bien adaptée et rapide',
      reasons: 'Cycle court de 90 à 120 jours, excellente couverture du sol contre l’érosion.',
      climateAndSoil: 'Sols meubles, légers, non gorgés d’eau.',
      pros: ['Récolte rapide en période de soudure', 'Feuilles consommables comme brèdes'],
      cons: ['Sensible aux charançons de la patate en sol trop sec'],
      bestPractices: 'Planter des boutures de tiges terminales de 30 cm sur billons.',
      soilAdvice: 'Éviter les excès d’azote qui développent le feuillage au détriment des tubercules.'
    },
    adaptationByLocality: {}
  },
  {
    id: 'taro',
    name: 'Taro',
    category: 'Tubercules',
    duration: '6-9 mois',
    description: 'Tubercule rustique appréciant les zones fraîches et humides.',
    image: CROP_IMAGES.taro,
    isPrincipal: false,
    steps: createStepsForCrop('Taro', CROP_IMAGES.taro),
    defaultAdaptation: {
      level: 'ADAPTEE',
      levelLabel: 'Très adaptée en zones humides',
      reasons: 'Supporte les sols très humides et les bas-fonds ombragés du Sud et du Centre.',
      climateAndSoil: 'Sols riches en matière organique et constamment frais.',
      pros: ['Pousse très bien sous couvert d’arbres fruitiers', 'Faible besoin en intrants chimiques'],
      cons: ['Ne supporte pas le dessèchement prolongé du sol'],
      bestPractices: 'Planter les rejets avec un morceau de tubercule dans des trous bien fumés.',
      soilAdvice: 'Paillage abondant avec des feuilles de bananier ou des herbes coupées.'
    },
    adaptationByLocality: {}
  },

  // 3. LÉGUMINEUSES
  {
    id: 'arachide',
    name: 'Arachide',
    category: 'Légumineuses',
    duration: '3-4 mois',
    description: 'Enrichit le sol en azote naturel et fournit des graines nutritives.',
    image: CROP_IMAGES.arachide,
    isPrincipal: false,
    steps: createStepsForCrop('Arachide', CROP_IMAGES.arachide),
    defaultAdaptation: {
      level: 'ADAPTEE',
      levelLabel: 'Très bien adaptée',
      reasons: 'Remarquable dans le Centre et le Nord (Bouaké, Korhogo, Katiola).',
      climateAndSoil: 'Sols légers sablo-limoneux facilitant la pénétration des gousses.',
      pros: ['Fixe l’azote atmosphérique et enrichit le sol', 'Revenus rapides et graines faciles à stocker'],
      cons: ['Sensible aux fortes pluies en fin de cycle (risque de germination sur pied)'],
      bestPractices: 'Biner au stade début floraison pour ameublir la zone d’enfouissement des gynophores.',
      soilAdvice: 'Apport de phosphate naturel ou compost sans excès d’azote.'
    },
    adaptationByLocality: {}
  },
  {
    id: 'haricot',
    name: 'Haricot',
    category: 'Légumineuses',
    duration: '2-3 mois',
    description: 'Légumineuse protéinée à croissance très rapide (niébé / haricot vert).',
    image: CROP_IMAGES.haricot,
    isPrincipal: false,
    steps: createStepsForCrop('Haricot', CROP_IMAGES.haricot),
    defaultAdaptation: {
      level: 'ADAPTEE',
      levelLabel: 'Adaptée et polyvalente',
      reasons: 'Excellente culture d’association ou intercalaire avec le maïs et le manioc.',
      climateAndSoil: 'Sols bien drainés, tolère une fertilité modérée.',
      pros: ['Cycle ultra court (60 à 75 jours)', 'Excellente source de protéines végétales'],
      cons: ['Attaques fréquentes de pucerons et thrips sur fleurs'],
      bestPractices: 'Semer à 40x20 cm et associer avec le maïs.',
      soilAdvice: 'Inoculation ou compost léger pour stimuler les nodosités fixatrices d’azote.'
    },
    adaptationByLocality: {}
  },

  // 4. MARAÎCHAGE
  {
    id: 'tomate',
    name: 'Tomate',
    category: 'Maraîchage',
    duration: '3 mois',
    description: 'Culture maraîchère à rotation rapide et très forte rentabilité.',
    image: CROP_IMAGES.tomate,
    isPrincipal: false,
    steps: createStepsForCrop('Tomate', CROP_IMAGES.tomate),
    defaultAdaptation: {
      level: 'MOYENNE',
      levelLabel: 'Productive mais exigeante',
      reasons: 'Idéale en contre-saison avec point d’eau ou en zone à hygrométrie modérée.',
      climateAndSoil: 'Sols légers, profonds, riches en potassium et bien drainés.',
      pros: ['Rotation rapide et revenus hebdomadaires au marché', 'Demande constante en cuisine locale'],
      cons: ['Sensible au flétrissement bactérien et aux champignons en cas de fortes pluies'],
      bestPractices: 'Pépinière soignée, repiquage à 80x50 cm, tuteurage obligatoire et paillage.',
      soilAdvice: 'Apports de cendres de bois riches en potasse et compost mûr.'
    },
    adaptationByLocality: {}
  },
  {
    id: 'piment',
    name: 'Piment',
    category: 'Maraîchage',
    duration: '4-6 mois',
    description: 'Condiment incontournable de la cuisine ivoirienne (piment bec d’oiseau, antillais).',
    image: CROP_IMAGES.piment,
    isPrincipal: false,
    steps: createStepsForCrop('Piment', CROP_IMAGES.piment),
    defaultAdaptation: {
      level: 'ADAPTEE',
      levelLabel: 'Très bien adaptée et rentable',
      reasons: 'Supporte bien la chaleur ivoirienne et produit pendant plusieurs mois consécutifs.',
      climateAndSoil: 'Sols limoneux bien aérés, ensoleillement direct.',
      pros: ['Récoltes multiples échelonnées sur 4 à 6 mois', 'Prix très élevé en période sèche'],
      cons: ['Levée lente des graines en pépinière (15 à 20 jours)'],
      bestPractices: 'Bien protéger la pépinière du soleil brûlant et repiquer des plants robustes.',
      soilAdvice: 'Fumure organique abondante au fond des trous de repiquage.'
    },
    adaptationByLocality: {}
  },
  {
    id: 'gombo',
    name: 'Gombo',
    category: 'Maraîchage',
    duration: '2-3 mois',
    description: 'Légume fruit très populaire pour les sauces gluantes traditionnelles.',
    image: CROP_IMAGES.gombo,
    isPrincipal: false,
    steps: createStepsForCrop('Gombo', CROP_IMAGES.gombo),
    defaultAdaptation: {
      level: 'ADAPTEE',
      levelLabel: 'Culture rustique et productive',
      reasons: 'Le gombo résiste bien aux fortes chaleurs et réussit sur presque tous les sols ivoiriens.',
      climateAndSoil: 'Sols perméables, riches en matière organique, plein soleil.',
      pros: ['Entrée en production dès 50 jours après semis', 'Cueillettes répétées tous les 2 à 3 jours'],
      cons: ['Les gousses durcissent vite si la cueillette tarde'],
      bestPractices: 'Semer direct en poquets de 3 graines espacés de 60x40 cm.',
      soilAdvice: 'Apporter un paillage pour garder le sol frais.'
    },
    adaptationByLocality: {}
  },
  {
    id: 'oignon',
    name: 'Oignon',
    category: 'Maraîchage',
    duration: '3-4 mois',
    description: 'Bulbe de grande consommation, adapté aux sols meubles et ensoleillés.',
    image: CROP_IMAGES.oignon,
    isPrincipal: false,
    steps: createStepsForCrop('Oignon', CROP_IMAGES.oignon),
    defaultAdaptation: {
      level: 'MOYENNE',
      levelLabel: 'Adaptée en saison sèche fraîche ou au Nord',
      reasons: 'Pousse particulièrement bien dans le Nord (Korhogo, Sinématiali) et sous irrigation.',
      climateAndSoil: 'Sols sablo-limoneux bien drainés, sans excès d’humidité stagnante.',
      pros: ['Très forte demande nationale et excellente conservation des bulbes bien séchés'],
      cons: ['Craint les fortes pluies prolongées qui font pourrir les bulbes'],
      bestPractices: 'Repiquer sur planches surélevées et arrêter les arrosages 2 semaines avant la récolte.',
      soilAdvice: 'Pas de fumier frais, privilégier le compost mûr et la cendre de bois.'
    },
    adaptationByLocality: {}
  },

  // 5. AUTRES
  {
    id: 'banane_plantain',
    name: 'Banane plantain',
    category: 'Autres',
    duration: '9-12 mois',
    description: 'Idéal pour les zones humides, très productif.',
    image: CROP_IMAGES.banane,
    isPrincipal: false,
    steps: createStepsForCrop('Banane plantain', CROP_IMAGES.banane),
    defaultAdaptation: {
      level: 'ADAPTEE',
      levelLabel: 'Idéale en zone forestière et Centre humide',
      reasons: 'Excellente adaptation dans tout le Sud et le Centre (Soubré, Gagnoa, Divo, Abengourou, Yamoussoukro).',
      climateAndSoil: 'Précipitations abondantes (> 1 300 mm/an), sol profond, riche en matière organique.',
      pros: ['Prix de vente très rémunérateur pour la cuisine locale (foutou, alloco)', 'Peut être associé au jeune verger'],
      cons: ['Sensible aux coups de vent violents (verse) et aux charançons du bananier'],
      bestPractices: 'Parer les rejets (épluchage de la souche) avant plantation et pailler généreusement le pied.',
      soilAdvice: 'Apports massifs de matière organique (coques de cacao, compost, paillis).'
    },
    adaptationByLocality: {}
  }
];

export function getCropById(id: string): Crop {
  const crop = CROPS_DATA.find((c) => c.id === id);
  return crop || CROPS_DATA[0];
}

export function getCropAdaptation(crop: Crop, locality: string): LocalityAdaptation {
  if (!locality) return crop.defaultAdaptation;
  const normLoc = locality.toLowerCase().trim();
  for (const [key, adaptation] of Object.entries(crop.adaptationByLocality)) {
    if (normLoc.includes(key)) {
      return adaptation;
    }
  }
  return crop.defaultAdaptation;
}

export function getCropWithProgress(
  crop: Crop,
  progressMap?: Record<number, StepProgressData>
): Crop {
  const updatedSteps = crop.steps.map((step) => {
    const userStep = progressMap ? progressMap[step.id] : undefined;
    if (userStep && userStep.completed) {
      return {
        ...step,
        completed: true,
        completedDate: userStep.completedDate,
        photoProof: userStep.photoProof,
        validationStatus: userStep.validationStatus || ('valide' as const),
      };
    }
    return {
      ...step,
      completed: false,
      completedDate: undefined,
      photoProof: undefined,
      validationStatus: 'non_commence' as const,
    };
  });

  return {
    ...crop,
    steps: updatedSteps,
  };
}

export function getCropByIdWithProgress(
  id: string,
  userProfile?: UserProfile
): Crop {
  const baseCrop = getCropById(id);
  const progressMap = userProfile?.cropProgress?.[id];
  return getCropWithProgress(baseCrop, progressMap);
}

export function calculateCropProgressPercent(crop: Crop): number {
  const total = crop.steps.length || 6;
  const completed = crop.steps.filter((s) => s.completed).length;
  if (total === 0 || completed === 0) return 0;
  return Math.min(100, Math.round((completed / total) * 100));
}
