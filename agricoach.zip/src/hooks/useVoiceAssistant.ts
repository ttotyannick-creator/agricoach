/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useCallback, useEffect, useRef, useState } from 'react';
import { UserProfile } from '../types/agricoach';

interface UseVoiceAssistantProps {
  userProfile: UserProfile;
  cropName: string;
  currentStepNumber: number;
  currentStepTitle: string;
  completedStepsTitles: string[];
  enabled: boolean;
  onQuestionResolved?: (query: string, reply: string) => void;
}

export function useVoiceAssistant({
  userProfile,
  cropName,
  currentStepNumber,
  currentStepTitle,
  completedStepsTitles,
  enabled,
  onQuestionResolved
}: UseVoiceAssistantProps) {
  const [isSupported, setIsSupported] = useState<boolean>(true);
  const [isListening, setIsListening] = useState<boolean>(false);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [isHandsFreeActive, setIsHandsFreeActive] = useState<boolean>(true);
  const [transcript, setTranscript] = useState<string>('');
  const [lastResponse, setLastResponse] = useState<string>('');
  const [statusMessage, setStatusMessage] = useState<string>('Prêt');
  const [hasGreeted, setHasGreeted] = useState<boolean>(false);

  const recognitionRef = useRef<any>(null);
  const isSpeakingRef = useRef<boolean>(false);
  const isHandsFreeActiveRef = useRef<boolean>(true);
  const silenceTimeoutRef = useRef<any>(null);
  const lastProcessedTranscriptRef = useRef<string>('');

  isSpeakingRef.current = isSpeaking;
  isHandsFreeActiveRef.current = isHandsFreeActive;

  // Arrêt de la reconnaissance vocale
  const stopListening = useCallback(() => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.abort();
      } catch (e) {
        // Ignorer les erreurs si déjà arrêté
      }
    }
    setIsListening(false);
  }, []);

  // Démarre l'écoute vocale
  const startListening = useCallback(() => {
    if (!enabled || !isSupported || isSpeakingRef.current || !isHandsFreeActiveRef.current) {
      return;
    }

    if (!recognitionRef.current) {
      return;
    }

    try {
      recognitionRef.current.start();
      setIsListening(true);
      setStatusMessage('À l’écoute...');
    } catch (e: any) {
      // Déjà démarré ou en cours
      if (e.name !== 'InvalidStateError') {
        console.warn('Erreur start speech recognition:', e);
      }
    }
  }, [enabled, isSupported]);

  // Synthèse vocale avec protection anti-boucle écho
  const speakText = useCallback(
    (text: string, onEndCallback?: () => void) => {
      if (typeof window === 'undefined' || !window.speechSynthesis) {
        return;
      }

      // Stopper la reconnaissance pour ne pas s'écouter soi-même
      stopListening();

      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'fr-FR';
      utterance.rate = 0.95; // Un peu plus posé pour une compréhension parfaite sur le terrain
      utterance.pitch = 1.0;

      // Sélectionner une voix française si disponible
      const voices = window.speechSynthesis.getVoices();
      const frenchVoice = voices.find(v => v.lang.startsWith('fr'));
      if (frenchVoice) {
        utterance.voice = frenchVoice;
      }

      utterance.onstart = () => {
        setIsSpeaking(true);
        setStatusMessage('AgriCoach vous parle...');
      };

      utterance.onend = () => {
        setIsSpeaking(false);
        setStatusMessage('Prêt');
        if (onEndCallback) {
          onEndCallback();
        }
        // Reprise automatique de l'écoute après 500ms si le mode mains libres est activé
        setTimeout(() => {
          if (isHandsFreeActiveRef.current && enabled) {
            startListening();
          }
        }, 500);
      };

      utterance.onerror = (err) => {
        console.warn('Erreur SpeechSynthesis:', err);
        setIsSpeaking(false);
        setStatusMessage('Prêt');
        setTimeout(() => {
          if (isHandsFreeActiveRef.current && enabled) {
            startListening();
          }
        }, 500);
      };

      window.speechSynthesis.speak(utterance);
    },
    [stopListening, startListening, enabled]
  );

  // Envoi de la question au serveur pour réponse personnalisée
  const handleUserQuery = useCallback(
    async (queryText: string) => {
      const clean = queryText.trim();
      if (!clean || clean.length < 2) return;

      setStatusMessage('Réflexion agricole...');
      setTranscript(clean);

      try {
        const response = await fetch('/api/voice-assistant', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userQuery: clean,
            userName: userProfile.name || 'Cher agriculteur',
            userLocality: userProfile.locality || 'Yamoussoukro',
            cropName,
            currentStepNumber,
            currentStepTitle,
            completedSteps: completedStepsTitles,
          }),
        });

        const data = await response.json();
        const reply = data.responseText || `Je vous conseille de bien vérifier le sol pour votre culture de ${cropName}.`;
        setLastResponse(reply);
        if (onQuestionResolved) {
          onQuestionResolved(clean, reply);
        }

        speakText(reply);
      } catch (err) {
        console.error('Erreur API vocale:', err);
        const fallback = `Pour votre parcelle de ${cropName} à ${userProfile.locality || 'Yamoussoukro'}, veillez à l'étape : ${currentStepTitle}.`;
        setLastResponse(fallback);
        speakText(fallback);
      }
    },
    [userProfile, cropName, currentStepNumber, currentStepTitle, completedStepsTitles, onQuestionResolved, speakText]
  );

  // Initialisation de la reconnaissance vocale
  useEffect(() => {
    if (typeof window === 'undefined') return;

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setIsSupported(false);
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'fr-FR';
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => {
      setIsListening(true);
      setStatusMessage('À l’écoute...');
    };

    recognition.onresult = (event: any) => {
      // Ignorer si l'assistant parle
      if (isSpeakingRef.current) return;

      let currentInterim = '';
      let finalTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; ++i) {
        const item = event.results[i];
        if (item.isFinal) {
          finalTranscript += item[0].transcript;
        } else {
          currentInterim += item[0].transcript;
        }
      }

      const textToShow = finalTranscript || currentInterim;
      if (textToShow) {
        setTranscript(textToShow);
      }

      if (finalTranscript) {
        const cleanFinal = finalTranscript.trim();
        if (cleanFinal && cleanFinal !== lastProcessedTranscriptRef.current) {
          lastProcessedTranscriptRef.current = cleanFinal;
          clearTimeout(silenceTimeoutRef.current);
          handleUserQuery(cleanFinal);
        }
      } else if (currentInterim) {
        // En cas de silence prolongé sur un résultat intérimaire
        clearTimeout(silenceTimeoutRef.current);
        silenceTimeoutRef.current = setTimeout(() => {
          const cleanInterim = currentInterim.trim();
          if (cleanInterim && cleanInterim !== lastProcessedTranscriptRef.current && cleanInterim.length > 3) {
            lastProcessedTranscriptRef.current = cleanInterim;
            handleUserQuery(cleanInterim);
          }
        }, 1800);
      }
    };

    recognition.onerror = (event: any) => {
      // Erreurs normales de silence ou interruption
      if (event.error === 'no-speech' || event.error === 'aborted') {
        return;
      }
      console.warn('Speech recognition status:', event.error);
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
      // Si le mode mains libres est activé et qu'on ne parle pas, relancer l'écoute
      if (isHandsFreeActiveRef.current && !isSpeakingRef.current && enabled) {
        setTimeout(() => {
          if (isHandsFreeActiveRef.current && !isSpeakingRef.current && enabled) {
            try {
              recognition.start();
            } catch (e) {
              // Ignore
            }
          }
        }, 400);
      }
    };

    recognitionRef.current = recognition;

    return () => {
      clearTimeout(silenceTimeoutRef.current);
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch (e) {
          // Ignore
        }
      }
    };
  }, [handleUserQuery, enabled]);

  // Arrêter tout si enabled passe à faux
  useEffect(() => {
    if (!enabled) {
      stopListening();
      if (typeof window !== 'undefined' && window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
      setIsSpeaking(false);
      setIsListening(false);
    }
  }, [enabled, stopListening]);

  // Accueil vocal automatique à l'ouverture de l'application
  const triggerAutoWelcome = useCallback(() => {
    if (!enabled || hasGreeted) return;
    setHasGreeted(true);

    const firstName = userProfile.name ? userProfile.name.split(' ')[0] : 'l’ami';
    const welcomeMsg = `Salut ${firstName} ! Bienvenue sur AgriCoach. Que souhaites-tu faire aujourd'hui ?`;
    setLastResponse(welcomeMsg);

    // Petit délai d'initialisation de la page
    setTimeout(() => {
      speakText(welcomeMsg, () => {
        // Après avoir parlé, active l'écoute vocale
        if (enabled) {
          startListening();
        }
      });
    }, 800);
  }, [enabled, hasGreeted, userProfile.name, speakText, startListening]);

  // Bascule du mode mains libres
  const toggleHandsFree = useCallback(() => {
    setIsHandsFreeActive((prev) => {
      const next = !prev;
      if (!next) {
        stopListening();
        window.speechSynthesis?.cancel();
        setIsSpeaking(false);
        setStatusMessage('Mains libres désactivé');
      } else {
        setStatusMessage('Mains libres activé');
        startListening();
      }
      return next;
    });
  }, [stopListening, startListening]);

  return {
    isSupported,
    isListening,
    isSpeaking,
    isHandsFreeActive,
    transcript,
    lastResponse,
    statusMessage,
    startListening,
    stopListening,
    speakText,
    triggerAutoWelcome,
    toggleHandsFree,
    handleUserQuery,
  };
}
