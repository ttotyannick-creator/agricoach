/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type CropCategory = 'Céréales' | 'Tubercules' | 'Légumineuses' | 'Maraîchage' | 'Autres';

export type AdaptationLevel = 'ADAPTEE' | 'MOYENNE' | 'PEU_ADAPTEE';

export interface LocalityAdaptation {
  level: AdaptationLevel;
  levelLabel: string;
  reasons: string;
  climateAndSoil: string;
  pros: string[];
  cons: string[];
  bestPractices: string;
  soilAdvice: string;
  alternatives?: string[];
}

export interface QuizQuestion {
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface ProductionStep {
  id: number;
  stepNumber: number;
  title: string;
  shortDescription: string;
  detailedGuidance: {
    what: string;
    how: string;
    when: string;
    why: string;
  };
  durationText: string;
  badgeText?: string;
  image: string;
  videoTitle?: string;
  videoDuration?: string;
  quizQuestions: QuizQuestion[];
  quiz?: QuizQuestion;
  completed: boolean;
  completedDate?: string;
  photoProof?: string;
  validationStatus?: 'non_commence' | 'video_vue' | 'qcm_valide' | 'photo_soumise' | 'valide';
}

export interface Crop {
  id: string;
  name: string;
  category: CropCategory;
  duration: string;
  description: string;
  image: string;
  isPrincipal?: boolean;
  steps: ProductionStep[];
  adaptationByLocality: Record<string, LocalityAdaptation>;
  defaultAdaptation: LocalityAdaptation;
}

export interface StepProgressData {
  completed: boolean;
  completedDate?: string;
  photoProof?: string;
  validationStatus?: 'non_commence' | 'video_vue' | 'qcm_valide' | 'photo_soumise' | 'valide';
}

export interface UserProfile {
  name: string;
  locality: string;
  cropSelectedId: string;
  isOnboarded: boolean;
  isVoiceAssistantEnabled?: boolean;
  cropProgress?: Record<string, Record<number, StepProgressData>>;
}

export interface VoiceState {
  isSupported: boolean;
  isListening: boolean;
  isSpeaking: boolean;
  isHandsFreeEnabled: boolean;
  transcript: string;
  lastAssistantSpeech: string;
  hasPermission: boolean | null;
  statusText: string;
}
