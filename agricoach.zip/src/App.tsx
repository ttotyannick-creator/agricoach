/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useState } from 'react';
import { ActivitiesScreen } from './components/ActivitiesScreen';
import { BottomNav, NavTab } from './components/BottomNav';
import { CalendarScreen } from './components/CalendarScreen';
import { CropSelectionScreen } from './components/CropSelectionScreen';
import { CropsScreen } from './components/CropsScreen';
import { HomeScreen } from './components/HomeScreen';
import { OnboardingScreen } from './components/OnboardingScreen';
import { ProfileScreen } from './components/ProfileScreen';
import { ProgressionScreen } from './components/ProgressionScreen';
import { WeatherScreen } from './components/WeatherScreen';
import { getCropByIdWithProgress } from './data/agronomyData';
import { useVoiceAssistant } from './hooks/useVoiceAssistant';
import { UserProfile } from './types/agricoach';

const STORAGE_KEY = 'agricoach_user_profile_v3';

const INITIAL_PROFILE: UserProfile = {
  name: '',
  locality: '',
  cropSelectedId: 'mais',
  isOnboarded: false,
  isVoiceAssistantEnabled: true,
  cropProgress: {},
};

type OnboardingPhase = 'identification' | 'crop_selection' | 'completed';
type DashboardSubView = 'none' | 'weather' | 'calendar' | 'progression';

export default function App() {
  const [userProfile, setUserProfile] = useState<UserProfile>(() => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        try {
          const parsed = JSON.parse(stored);
          if (parsed && typeof parsed.isOnboarded === 'boolean') {
            return {
              ...INITIAL_PROFILE,
              ...parsed,
              cropProgress: parsed.cropProgress || {},
            };
          }
        } catch (e) {
          // Utilise le profil initial
        }
      }
      // Migration sans artifice : si un profil antérieur existe, on conserve nom/localité mais la progression démarre strictement à 0%
      const storedV2 = localStorage.getItem('agricoach_user_profile_v2');
      if (storedV2) {
        try {
          const parsedV2 = JSON.parse(storedV2);
          if (parsedV2 && typeof parsedV2.isOnboarded === 'boolean') {
            return {
              ...INITIAL_PROFILE,
              name: parsedV2.name || '',
              locality: parsedV2.locality || '',
              cropSelectedId: parsedV2.cropSelectedId || 'mais',
              isOnboarded: parsedV2.isOnboarded,
              isVoiceAssistantEnabled: parsedV2.isVoiceAssistantEnabled !== false,
              cropProgress: {}, // Strictement à 0%
            };
          }
        } catch (e) {
          // Pas d'action
        }
      }
    }
    return INITIAL_PROFILE;
  });

  const [onboardingPhase, setOnboardingPhase] = useState<OnboardingPhase>(() =>
    userProfile.isOnboarded ? 'completed' : 'identification'
  );

  const [currentTab, setCurrentTab] = useState<NavTab>('home');
  const [dashboardSubView, setDashboardSubView] = useState<DashboardSubView>('none');
  const [targetStepIndex, setTargetStepIndex] = useState<number>(0);

  // Synchronisation automatique et persistante avec localStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(userProfile));
  }, [userProfile]);

  const activeCrop = getCropByIdWithProgress(userProfile.cropSelectedId, userProfile);
  const activeStep = activeCrop.steps[0] || {
    id: 1,
    stepNumber: 1,
    title: 'Préparation et diagnostic du sol',
  };
  const completedStepsTitles = activeCrop.steps
    .filter((s) => s.completed)
    .map((s) => s.title);

  // Hook assistant vocal
  const voiceAssistant = useVoiceAssistant({
    userProfile,
    cropName: activeCrop.name,
    currentStepNumber: activeStep.stepNumber || 1,
    currentStepTitle: activeStep.title,
    completedStepsTitles,
    enabled: userProfile.isOnboarded && userProfile.isVoiceAssistantEnabled !== false,
  });

  // Déclencher l'accueil vocal automatique dès l'arrivée sur l'écran principal (sans popup)
  useEffect(() => {
    if (userProfile.isOnboarded && userProfile.isVoiceAssistantEnabled !== false) {
      voiceAssistant.triggerAutoWelcome();
    }
  }, [userProfile.isOnboarded, userProfile.isVoiceAssistantEnabled]);

  // 1. Écran d'identification renseigné -> passage au choix de la culture
  const handleIdentificationComplete = (data: { name: string; locality: string }) => {
    setUserProfile((prev) => ({
      ...prev,
      name: data.name,
      locality: data.locality,
    }));
    setOnboardingPhase('crop_selection');
  };

  // 2. Sélection de la culture initiale -> accès à l'espace agricole avec progression à 0%
  const handleInitialCropSelected = (cropId: string) => {
    setUserProfile((prev) => ({
      ...prev,
      cropSelectedId: cropId,
      isOnboarded: true,
      cropProgress: prev.cropProgress || {},
    }));
    setOnboardingPhase('completed');
    setCurrentTab('home');
    setDashboardSubView('none');
  };

  // Mise à jour profil
  const handleUpdateProfile = (updated: Partial<UserProfile>) => {
    setUserProfile((prev) => ({
      ...prev,
      ...updated,
    }));
  };

  // Validation effective d'une étape : enregistrement dynamique et persistant
  const handleValidateStep = (
    cropId: string,
    stepId: number,
    data: { completedDate: string; photoProof?: string }
  ) => {
    setUserProfile((prev) => {
      const existingCropProgress = prev.cropProgress || {};
      const cropSteps = existingCropProgress[cropId] || {};

      const updatedCropSteps = {
        ...cropSteps,
        [stepId]: {
          completed: true,
          completedDate: data.completedDate,
          photoProof: data.photoProof,
          validationStatus: 'valide' as const,
        },
      };

      return {
        ...prev,
        cropProgress: {
          ...existingCropProgress,
          [cropId]: updatedCropSteps,
        },
      };
    });
  };

  // Déconnexion -> retour obligatoire à l'écran d'identification
  const handleLogout = () => {
    setUserProfile({
      name: '',
      locality: '',
      cropSelectedId: 'mais',
      isOnboarded: false,
      isVoiceAssistantEnabled: true,
      cropProgress: {},
    });
    setOnboardingPhase('identification');
    setDashboardSubView('none');
    setCurrentTab('home');
    voiceAssistant.stopListening();
  };

  const handleSelectCrop = (cropId: string) => {
    setUserProfile((prev) => ({
      ...prev,
      cropSelectedId: cropId,
    }));
  };

  // ==============================================================
  // 1. PARCOURS D'ACCÈS INITIAL OBLIGATOIRE (Identification & Choix)
  // ==============================================================
  if (!userProfile.isOnboarded || onboardingPhase !== 'completed') {
    if (onboardingPhase === 'identification') {
      return (
        <OnboardingScreen
          onComplete={handleIdentificationComplete}
          initialProfile={userProfile}
        />
      );
    }

    if (onboardingPhase === 'crop_selection') {
      return (
        <CropSelectionScreen
          userProfile={userProfile}
          onCropSelected={handleInitialCropSelected}
          onReadAloud={voiceAssistant.speakText}
        />
      );
    }
  }

  // ==============================================================
  // 2. ESPACE AGRICOLE PRINCIPAL (TABLEAU DE BORD, ÉCRANS & ONGLETS)
  // ==============================================================
  return (
    <div className="min-h-screen bg-background text-on-surface relative">
      {/* 2.1 ÉCRAN D'ACCUEIL OU SOUS-ÉCRANS DÉDIÉS (Météo, Calendrier, Progression) */}
      {currentTab === 'home' && (
        <>
          {dashboardSubView === 'none' && (
            <HomeScreen
              userProfile={userProfile}
              onOpenWeather={() => setDashboardSubView('weather')}
              onOpenCalendar={() => setDashboardSubView('calendar')}
              onOpenProgression={() => setDashboardSubView('progression')}
              onGoToActivities={() => {
                setDashboardSubView('none');
                setCurrentTab('activities');
              }}
              onReadAloud={voiceAssistant.speakText}
            />
          )}

          {/* VÉRITABLE ÉCRAN MÉTÉO (Image_8) */}
          {dashboardSubView === 'weather' && (
            <WeatherScreen
              userProfile={userProfile}
              onBack={() => setDashboardSubView('none')}
              onReadAloud={voiceAssistant.speakText}
            />
          )}

          {/* VÉRITABLE ÉCRAN CALENDRIER (Image_9) */}
          {dashboardSubView === 'calendar' && (
            <CalendarScreen
              userProfile={userProfile}
              onBack={() => setDashboardSubView('none')}
              onReadAloud={voiceAssistant.speakText}
            />
          )}

          {/* VÉRITABLE ÉCRAN DE PROGRESSION DES 6 ÉTAPES (Image_4) */}
          {dashboardSubView === 'progression' && (
            <ProgressionScreen
              userProfile={userProfile}
              onBack={() => setDashboardSubView('none')}
              onGoToActivities={(stepIdx?: number) => {
                if (typeof stepIdx === 'number') {
                  setTargetStepIndex(stepIdx);
                }
                setDashboardSubView('none');
                setCurrentTab('activities');
              }}
              onReadAloud={voiceAssistant.speakText}
            />
          )}
        </>
      )}

      {/* 2.2 RUBRIQUE CULTURES (Catalogue complet des 13 cultures vivrières) */}
      {currentTab === 'crops' && (
        <CropsScreen
          userProfile={userProfile}
          selectedCropId={userProfile.cropSelectedId}
          onSelectCrop={handleSelectCrop}
          onGoToActivities={() => setCurrentTab('activities')}
          onReadAloud={voiceAssistant.speakText}
        />
      )}

      {/* 2.3 RUBRIQUE ACTIVITÉS (Parcours complet : Vidéo -> QCM 3 questions -> Photo -> Validation) */}
      {currentTab === 'activities' && (
        <ActivitiesScreen
          userProfile={userProfile}
          selectedCropId={userProfile.cropSelectedId}
          initialStepIndex={targetStepIndex}
          onValidateStep={handleValidateStep}
          onBackToCycle={() => {
            setCurrentTab('home');
            setDashboardSubView('progression');
          }}
          onReadAloud={voiceAssistant.speakText}
        />
      )}

      {/* 2.4 RUBRIQUE PROFIL (Paramètres, Assistant vocal on/off, FAQ, Déconnexion) */}
      {currentTab === 'profile' && (
        <ProfileScreen
          userProfile={userProfile}
          onUpdateProfile={handleUpdateProfile}
          onLogout={handleLogout}
          onReadAloud={voiceAssistant.speakText}
        />
      )}

      {/* Barre de navigation inférieure native */}
      <BottomNav
        currentTab={currentTab}
        onTabChange={(tab) => {
          setDashboardSubView('none');
          setCurrentTab(tab);
        }}
      />
    </div>
  );
}
