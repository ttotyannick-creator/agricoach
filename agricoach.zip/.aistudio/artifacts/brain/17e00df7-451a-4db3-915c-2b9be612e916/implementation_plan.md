# AgriCoach : Assistant Agricole Intelligent & Suivi de Production

Développement complet de la logique métier, de l'assistant vocal mains libres, de la personnalisation agronomique par localité ivoirienne et du suivi de cycle de culture, tout en conservant **intégralement et au pixel près le design, les écrans, les couleurs, les polices, les images et les icônes existants**.

---

## Décisions Clés & Confirmation Utilisateur

> [!IMPORTANT]
> **Respect absolu du design existant** : L'interface visuelle (les 6 écrans conçus : Bienvenue/Inscription, Accueil Météo & Conseil, Activités de l'étape, Cycle de culture & Historique, Catalogue/Choix de culture, Profil) est conservée à l'identique avec son système de couleurs Tailwind (Primary `#0d631b`, Primary-container `#2e7d32`, Secondary `#725a39`, etc.), sa typographie Inter et ses images réelles de cultures ivoiriennes. Aucun élément graphique ou décoratif inutile n'est ajouté.

- **Assistant vocal mains libres** : Implémentation via l'API Web Speech native (reconnaissance vocale continue + synthèse vocale fluide en français) couplée à un moteur d'intelligence agronomique (modèle `gemini-3.8-flash`). Un filtre anti-écho empêche l'assistant d'entendre sa propre voix. L'accueil vocal automatique s'active dès l'arrivée sur l'écran principal comme demandé.
- **Support hors-ligne et résilience** : Sauvegarde locale automatique (`localStorage`) du profil (nom, localité), de la culture sélectionnée, de l'avancement dans les 6 étapes et des tâches validées pour un fonctionnement fluide même en cas de réseau faible ou intermittent.
- **Réalisme agronomique ivoirien** : Données agronomiques vérifiées pour les principales zones écologiques de Côte d'Ivoire (Zone forestière/Sud : Yamoussoukro, Soubré, Daloa, Gagnoa ; Zone savane/Nord : Korhogo, Bouaké, Bondoukou, Odienné) adaptées aux cultures vivrières (Maïs, Riz, Manioc, Igname, Banane plantain, Maraîchage).

---

## 1. Vue d'Ensemble & Fonctionnalités

### Rôle d'AgriCoach
AgriCoach est un conseiller agronomique digital de terrain destiné en priorité aux agriculteurs débutants ou peu alphabétisés en Côte d'Ivoire. Il ne se limite pas à afficher des textes : il guide pas à pas l'agriculteur sur sa parcelle, explique les opérations à faire, permet de valider les étapes et converse oralement en continu.

### Parcours Utilisateur
1. **Inscription simple** : Saisie du Nom et de la Localité (sans aucun champ superflu).
2. **Accueil personnalisé** : Accueil vocal automatique (« Salut ! Bienvenue sur AgriCoach. Que souhaites-tu faire aujourd'hui ? »), affichage de la météo locale en direct, conseil agronomique du jour avec bouton « Marquer comme fait », prévisions sur 3 jours.
3. **Choix de culture & Adaptation locale** : Sélection de la culture avec diagnostic instantané d'adaptation selon la localité (Adaptée / Moyennement adaptée / Peu adaptée, sol requis, climat, atouts et contraintes, alternatives).
4. **Activités & Accompagnement en 6 étapes** :
   - Étape 1 : Préparation et diagnostic du sol (labour meuble 20 cm, fumure de fond)
   - Étape 2 : Fertilisation et restauration du sol (matière organique, compost, NPK)
   - Étape 3 : Semis ou plantation (espacements, profondeur, calendrier)
   - Étape 4 : Entretien de la culture (désherbage, sarclage, eau, surveillance ravageurs)
   - Étape 5 : Suivi de la production & calendrier (rappel d'urée, historique validé)
   - Étape 6 : Récolte (critères de maturité, stockage sans pertes)
5. **Actions interactives réelles** :
   - Bouton « J'ai réalisé » qui incrémente la progression (ex: 2/6 -> 3/6) et met à jour l'historique validé.
   - Bouton « Prendre une photo » avec prévisualisation réelle (caméra/galerie).
   - Bouton « J'ai un problème » ouvrant un diagnostic immédiat avec conseils de remédiation et support vocal.
   - Bouton « Regarder la vidéo » ouvrant la vidéo pédagogique avec quiz interactif associé.
   - Quiz agronomique avec feedback immédiat et félicitations vocales.
6. **Assistant vocal mains libres permanent** :
   - Écoute continue sans devoir rappuyer sur le micro.
   - Réponse orale immédiate et lecture à haute voix de tous les conseils et étapes.
   - Personnalisation complète : connaît le nom de l'agriculteur, sa localité, sa culture et son étape en cours.

---

## 2. Expérience Utilisateur & Intégrité Visuelle

L'application conserve strictement le design des maquettes fournies :

```
┌─────────────────────────────────────────────────────────────┐
│ TopAppBar: [Avatar] AgriCoach               [Voice/Notif]   │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  [Écran Actif selon l'onglet ou l'état]                     │
│                                                             │
│  • Onglet Accueil : Météo locale, Conseil du jour,          │
│                     Prévisions, Photo de champ              │
│  • Onglet Cultures : Jauge circulaire 75%, Étapes restantes,│
│                      Historique validé, Badge Statut        │
│  • Onglet Activités : Jauge 2/6, Carte active,              │
│                       Boutons J'ai réalisé / Photo / Aide,  │
│                       Quiz rapide interactif                │
│  • Onglet Profil : Carte agriculteur, Modifier Nom/Ville,   │
│                    Paramètres, Déconnexion                  │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│ BottomNavBar: [Accueil]   [Cultures]   [Activités]  [Profil]│
└─────────────────────────────────────────────────────────────┘
```

- **Palette de couleurs exacte** : 
  - Fond : `#fcf9f8`
  - Vert primaire : `#0d631b` / Conteneur primaire : `#2e7d32`
  - Terreux / Beige secondaire : `#fbdbb0` / `#725a39`
  - Texte : `#1b1b1b` / Outline : `#bfcaba`
- **Icônes & Images** : Intégration fidèle des icônes Material Symbols Outlined (`water_drop`, `agriculture`, `task_alt`, `play_circle`, `photo_camera`, `report_problem`, `quiz`, etc.) et réutilisation directe des photographies agricoles réalistes issues des assets fournis.
- **Intégration vocale discrète** : Indicateur d'écoute intégré dans la barre supérieure ou sous forme de micro discret dans l'en-tête existant, affichant l'état (Écoute en cours / En train de parler / En veille) sans altérer la disposition.

---

## 3. Décisions d'Ingénierie & Choix Techniques

### A. Moteur Vocal & Assistant Mains Libres
- **Reconnaissance vocale** : Utilisation de l'API standard `webkitSpeechRecognition` / `SpeechRecognition` configurée en français (`fr-FR`), en mode continu (`continuous: true`) et avec résultats intermédiaires (`interimResults: false`).
- **Protection anti-boucle (Echo Cancellation)** : Suspension automatique du micro pendant la lecture audio de la réponse de l'assistant, puis réactivation automatique dès la fin du texte prononcé.
- **Intelligence Agronomique Contextuelle** : Route API serveur `/api/voice-assistant` propulsée par `@google/genai` (modèle `gemini-3.8-flash`) avec un prompt système rigoureux ancré dans l'agronomie ivoirienne (cultures vivrières, pluviométrie bimodal/monomodal, types de sols ferrallitiques et hydromorphes, doses d'engrais NPK/Urée, lutte intégrée).

### B. Moteur d'Adaptation par Localité
- Base de connaissances intégrée couvrant les régions de Côte d'Ivoire :
  - **Centre / V-Baoulé (Yamoussoukro, Bouaké)** : Sol ferrallitique moyennement désaturé, savane arborée / transition forêt, deux saisons des pluies. Très adapté au maïs, manioc, igname, maraîchage sous irrigation.
  - **Sud / Forêt (Soubré, Abidjan, San-Pédro, Divo)** : Climat équatorial humide, fortes précipitations, adapté au manioc, banane plantain, maïs de première saison, cacao.
  - **Nord / Savane soudanienne (Korhogo, Ferké, Boundiali)** : Une seule saison des pluies, adapté aux céréales (maïs hâtif, sorgho, riz de bas-fond), arachide, coton.
  - **Est (Bondoukou, Abengourou)** : Zone de transition, idéale pour igname, maïs, anacarde.
- Analyse automatique du niveau d'adaptation : `Adaptée` (vert), `Moyennement adaptée` (orange), `Peu adaptée` (rouge) avec explications détaillées et alternatives suggérées.

### C. Persistance Locale & Données
- Persistance de l'état complet dans `localStorage` : profil, culture active, étape active (1 à 6), historique des étapes terminées avec dates, réponses aux quiz, statut du conseil du jour.
- Pas de perte de données en cas de rechargement ou de coupure réseau.

---

## 4. Architecture Technique & Flux de Données

```
┌─────────────────────────────────────────────────────────────┐
│                       Client (React)                        │
│                                                             │
│   ┌─────────────────────────────────────────────────────┐   │
│   │                 AgriCoach Context                   │   │
│   │  • Profil: { nom, localite }                        │   │
│   │  • Culture: { id, nom, etapeActuelle, progression } │   │
│   │  • VoiceState: { isListening, isSpeaking, transcript}│  │
│   └──────────────────────────┬──────────────────────────┘   │
│                              │                              │
│          ┌───────────────────┼───────────────────┐          │
│          ▼                   ▼                   ▼          │
│   ┌──────────────┐    ┌──────────────┐    ┌─────────────┐   │
│   │ Web Speech   │    │ Agronomic DB │    │ LocalStorage│   │
│   │ API (Mic/TTS)│    │ (CI Regions) │    │ Persistence │   │
│   └──────┬───────┘    └──────────────┘    └─────────────┘   │
└──────────┼──────────────────────────────────────────────────┘
           │ Questions complexes / Dialogue intelligent
           ▼
┌─────────────────────────────────────────────────────────────┐
│                 Serveur Backend (Express / Vite)            │
│  Endpoint: POST /api/voice-assistant                        │
│  • Intègre contexte: { user, culture, localite, etape }     │
│  • Modèle: gemini-3.8-flash via @google/genai               │
│  • Réponse concise, orale, accessible (français ivoirien)   │
└─────────────────────────────────────────────────────────────┘
```

### Plan d'Exécution par Fichiers
1. `metadata.json` : Nommer l'application « AgriCoach - Assistant Agricole Intelligent ».
2. `src/types/agricoach.ts` : Types pour le profil, les cultures, les 6 étapes de production, les quiz agronomiques et l'état vocal.
3. `src/data/agronomyData.ts` : Données agronomiques complètes et réalistes de Côte d'Ivoire (adaptation par localité, conseils de préparation du sol, fertilisation NPK/organique, semis, entretien, calendrier, quiz).
4. `server.ts` : Serveur Express avec route proxy `/api/voice-assistant` utilisant `@google/genai` (`gemini-3.8-flash`) pour répondre oralement aux questions agricoles contextuelles.
5. `src/hooks/useVoiceAssistant.ts` : Hook React gérant la boucle vocale continue mains libres, la synthèse vocale, l'accueil automatique et la protection anti-écho.
6. `src/components/` : Composants reproduisant scrupuleusement le design HTML/Tailwind :
   - `OnboardingScreen.tsx` : Écran d'inscription (Bienvenue, nom, localité).
   - `HomeScreen.tsx` : Écran d'accueil météo, conseil du jour avec bouton "Marquer comme fait", prévisions de la semaine.
   - `CropsScreen.tsx` : Suivi de cycle (jauge 75%, étapes restantes, historique validé) et catalogue de sélection avec diagnostic d'adaptation locale.
   - `ActivitiesScreen.tsx` : Étape en cours (Préparation du sol, 2/6 étapes), boutons "J'ai réalisé", "Prendre une photo", "J'ai un problème", vidéo intégrée et quiz interactif avec retour immédiat.
   - `ProfileScreen.tsx` : Gestion du profil (nom, localité), langue, assistance, déconnexion.
   - `VoiceAssistantBar.tsx` : Indicateur visuel discret d'écoute/parole avec bouton d'activation/désactivation du mode mains libres.
7. `src/App.tsx` : Orchestrateur avec navigation fluide entre les 4 onglets, gestion de l'accueil vocal automatique et persistance.
8. Compilation et vérification finale sans aucune régression visuelle.
